"use client";

import { useEffect, useMemo, useState } from "react";

export default function LoadCoveragePanel({ rows = [], onDeleteCoverageRows, onUpdateCoverageRows }) {  const [collapsedBooks, setCollapsedBooks] = useState({});
  const [collapsedSports, setCollapsedSports] = useState({});
  const [collapsedEvents, setCollapsedEvents] = useState({});
  const [showOnlyThin, setShowOnlyThin] = useState(false);
  const [panelCollapsed, setPanelCollapsed] = useState(false);

  const coverage = useMemo(() => buildCoverage(rows), [rows]);
  useEffect(() => {
    writeEvLoadedCoverageSnapshot(coverage);
  }, [coverage]);
  const visibleBooks = showOnlyThin
    ? coverage.books
        .map((book) => ({
          ...book,
          sports: book.sports
            .map((sport) => ({
              ...sport,
              events: sport.events.filter((event) => event.isThin),
            }))
            .filter((sport) => sport.events.length > 0),
        }))
        .filter((book) => book.sports.length > 0)
    : coverage.books;

  function updateCoverageEventSport({ bookmaker, sport, eventName, nextSport }) {
    if (typeof onUpdateCoverageRows !== "function") return;

    const resolvedSport = String(nextSport || "").trim().toUpperCase();
    if (!resolvedSport) return;
    if (resolvedSport === String(sport || "").trim().toUpperCase()) return;

    onUpdateCoverageRows({
      bookmaker,
      sport,
      eventName,
      patch: {
        sport: resolvedSport,
        league: resolvedSport,
        coverageSportEdited: true,
        manuallyEdited: true,
      },
    });
  }

  function markCoverageEventComplete({ bookmaker, sport, eventName }) {
    if (typeof onUpdateCoverageRows !== "function") return;

    onUpdateCoverageRows({
      bookmaker,
      sport,
      eventName,
      patch: {
        coverageMarkedComplete: true,
        coverageMarkedCompleteAt: new Date().toISOString(),
        manuallyEdited: true,
      },
    });
  }

  function unmarkCoverageEventComplete({ bookmaker, sport, eventName }) {
    if (typeof onUpdateCoverageRows !== "function") return;

    onUpdateCoverageRows({
      bookmaker,
      sport,
      eventName,
      patch: {
        coverageMarkedComplete: false,
        coverageMarkedCompleteAt: "",
        manuallyEdited: true,
      },
    });
  }

  function confirmDeleteCoverage({ bookmaker, sport, eventName, label }) {
    if (typeof onDeleteCoverageRows !== "function") return;

    const ok = window.confirm(`Delete ${label}? This removes matching parsed rows from EV Lab.`);

    if (!ok) return;

    onDeleteCoverageRows({ bookmaker, sport, eventName });
  }

  if (!Array.isArray(rows) || rows.length === 0) {
    return (
      <section style={sectionStyle}>
        <div style={headerRowStyle}>
          <div>
            <h2 style={h2Style}>Loaded Coverage</h2>
            <div style={subtleStyle}>
              Import odds to see which books, sports, events, and markets are loaded.
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (panelCollapsed) {
    return (
      <section style={sectionStyle}>
        <div style={headerRowStyle}>
          <div>
            <h2 style={h2Style}>Loaded Coverage</h2>
            <div style={subtleStyle}>
              Hidden for now. Reopen it if you want to check loaded books, leagues, games, and markets again.
            </div>
          </div>

          <div style={headerButtonRowStyle}>
            <span style={summaryPillStyle}>Books: {coverage.bookCount}</span>
            <span style={summaryPillStyle}>Events: {coverage.eventCount}</span>
            <span style={summaryPillStyle}>Markets: {coverage.marketCount}</span>
            <span style={summaryPillStyle}>Rows: {coverage.rowCount}</span>

            <button
              type="button"
              onClick={() => setPanelCollapsed(false)}
              style={showThinButtonStyle}
            >
              Show Loaded Coverage
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section style={sectionStyle}>
      <div style={headerRowStyle}>
        <div>
          <h2 style={h2Style}>Loaded Coverage</h2>
          <div style={subtleStyle}>
            Use this to spot games or books that only loaded a few markets.
          </div>
        </div>

        <div style={headerButtonRowStyle}>
          <span style={summaryPillStyle}>Books: {coverage.bookCount}</span>
          <span style={summaryPillStyle}>Events: {coverage.eventCount}</span>
          <span style={summaryPillStyle}>Markets: {coverage.marketCount}</span>
          <span style={summaryPillStyle}>Rows: {coverage.rowCount}</span>

          <button
            type="button"
            onClick={() => setShowOnlyThin((prev) => !prev)}
            style={showThinButtonStyle}
          >
            {showOnlyThin ? "Show All" : "Show Thin Only"}
          </button>

          <button
            type="button"
            onClick={() => setPanelCollapsed(true)}
            style={showThinButtonStyle}
          >
            Hide Loaded Coverage
          </button>
        </div>
      </div>

      {visibleBooks.length === 0 ? (
        <div style={emptyThinStyle}>
          No thin/possibly incomplete events found.
        </div>
      ) : (
        <div style={{ display: "grid", gap: 10 }}>
          {visibleBooks.map((book) => {
            const bookKey = book.bookmaker;
            const bookCollapsed = !!collapsedBooks[bookKey];

            return (
              <div key={bookKey} style={bookCardStyle}>
                <div style={coverageHeaderActionRowStyle}>
                  <button
                    type="button"
                    onClick={() =>
                      setCollapsedBooks((prev) => ({
                        ...prev,
                        [bookKey]: !prev[bookKey],
                      }))
                    }
                    style={bookHeaderButtonStyle}
                  >
                    <span>
                      {bookCollapsed ? "Show" : "Hide"} {book.bookmaker}
                    </span>
                    <span style={bookMetaStyle}>
                      {book.eventCount} events • {book.marketCount} markets • {book.rowCount} rows
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      confirmDeleteCoverage({
                        bookmaker: book.bookmaker,
                        label: `all ${book.bookmaker} rows`,
                      })
                    }
                    style={deleteCoverageButtonStyle}
                  >
                    Delete Book
                  </button>
                </div>

                {!bookCollapsed ? (
                  <div style={{ display: "grid", gap: 10, marginTop: 10 }}>
                    {book.sports.map((sport) => {
                      const sportKey = `${bookKey}_${sport.sport}`;
                      const sportCollapsed = !!collapsedSports[sportKey];

                      return (
                        <div key={sportKey} style={sportCardStyle}>
                          <div style={{ ...coverageHeaderActionRowStyle, marginBottom: 8 }}>
                            <button
                              type="button"
                              onClick={() =>
                                setCollapsedSports((prev) => ({
                                  ...prev,
                                  [sportKey]: !prev[sportKey],
                                }))
                              }
                              style={{ ...sportHeaderButtonStyle, flex: 1, marginBottom: 0 }}
                            >
                              <span>
                                {sportCollapsed ? "Show" : "Hide"} {sport.sport || "UNKNOWN"} ({sport.eventCount} events)
                              </span>
                              <span style={sportMetaStyle}>
                                {sport.marketCount} markets • {sport.rowCount} rows
                              </span>
                            </button>

                            <button
                              type="button"
                              onClick={() =>
                                confirmDeleteCoverage({
                                  bookmaker: book.bookmaker,
                                  sport: sport.sport,
                                  label: `${book.bookmaker} ${sport.sport || "UNKNOWN"} rows`,
                                })
                              }
                              style={deleteCoverageButtonStyle}
                            >
                              Delete Sport
                            </button>
                          </div>

                          {!sportCollapsed ? (
                            <div style={{ display: "grid", gap: 8 }}>
                              {sport.events.map((event) => {
                                const eventKey = `${bookKey}::${sport.sport}::${event.eventName}`;
                                const eventCollapsed = !!collapsedEvents[eventKey];

                                return (
                                  <div
                                    key={eventKey}
                                    style={{
                                      ...eventCardStyle,
                                      ...(event.isThin ? thinEventStyle : null),
                                    }}
                                  >
                                    <div style={coverageHeaderActionRowStyle}>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setCollapsedEvents((prev) => ({
                                            ...prev,
                                            [eventKey]: !prev[eventKey],
                                          }))
                                        }
                                        style={{ ...eventHeaderButtonStyle, flex: 1 }}
                                      >
                                        <span>
                                          {eventCollapsed ? "Show" : "Hide"} {event.eventName}
                                        </span>

                                        <span style={eventMetaWrapStyle}>
                                          {event.coverageMarkedComplete ? (
                                            <span style={completeBadgeStyle}>
                                              Marked complete
                                            </span>
                                          ) : event.isThin ? (
                                            <span style={thinBadgeStyle}>
                                              Possibly incomplete
                                            </span>
                                          ) : null}

                                          {event.loadedAtLabel ? (
                                            <span style={eventTimestampStyle}>
                                              {event.loadedAtLabel}
                                            </span>
                                          ) : null}

                                          <span style={eventMetaStyle}>
                                            {event.marketCount} markets • {event.rowCount} rows
                                          </span>
                                        </span>
                                      </button>

                                      <label style={coverageSportSelectWrapStyle}>
                                        League
                                        <select
                                          value={sport.sport || "UNKNOWN"}
                                          onChange={(selectEvent) =>
                                            updateCoverageEventSport({
                                              bookmaker: book.bookmaker,
                                              sport: sport.sport,
                                              eventName: event.eventName,
                                              nextSport: selectEvent.target.value,
                                            })
                                          }
                                          style={coverageSportSelectStyle}
                                        >
                                          <option value="NBA">NBA</option>
                                          <option value="WNBA">WNBA</option>
                                          <option value="NHL">NHL</option>
                                          <option value="MLB">MLB</option>
                                          <option value="UFC">UFC</option>
                                          <option value="GOLF">GOLF</option>
                                          <option value="TENNIS">TENNIS</option>
                                          <option value="SOCCER">SOCCER</option>
                                          <option value="UNKNOWN">UNKNOWN</option>
                                        </select>
                                      </label>

                                      {event.coverageMarkedComplete ? (
                                        <button
                                          type="button"
                                          onClick={() =>
                                            unmarkCoverageEventComplete({
                                              bookmaker: book.bookmaker,
                                              sport: sport.sport,
                                              eventName: event.eventName,
                                            })
                                          }
                                          style={markCompleteButtonStyle}
                                        >
                                          Unmark Complete
                                        </button>
                                      ) : (
                                        <button
                                          type="button"
                                          onClick={() =>
                                            markCoverageEventComplete({
                                              bookmaker: book.bookmaker,
                                              sport: sport.sport,
                                              eventName: event.eventName,
                                            })
                                          }
                                          style={markCompleteButtonStyle}
                                        >
                                          Mark Complete
                                        </button>
                                      )}

                                      <button
                                        type="button"
                                        onClick={() =>
                                          confirmDeleteCoverage({
                                            bookmaker: book.bookmaker,
                                            sport: sport.sport,
                                            eventName: event.eventName,
                                            label: `${book.bookmaker} ${sport.sport || "UNKNOWN"} ${event.eventName}`,
                                          })
                                        }
                                        style={deleteCoverageButtonStyle}
                                      >
                                        Delete Event
                                      </button>
                                    </div>

                                    {!eventCollapsed ? (
                                      <>
                                        <div style={marketGridStyle}>
                                          {event.markets.map((market) => (
                                            <div
                                              key={`${eventKey}_${market.marketType}`}
                                              style={{
                                                ...marketPillStyle,
                                                ...(market.noSharpMatch ? unmatchedMarketPillStyle : null),
                                              }}
                                              title={
                                                market.noSharpMatch
                                                  ? "No matching sharp/fair market loaded for this target market."
                                                  : ""
                                              }
                                            >
                                              <span style={marketNameStyle}>{formatMarketLabel(market.marketType)}</span>
                                              <span style={marketCountStyle}>{market.rowCount} rows</span>
                                              {market.noSharpMatch ? (
                                                <span style={noSharpBadgeStyle}>No sharp</span>
                                              ) : null}
                                            </div>
                                          ))}
                                        </div>

                                        {event.missingSharpMarkets?.length ? (
                                          <div style={coverageWarningsStyle}>
                                            <div style={coverageWarningsTitleStyle}>
                                              Sharp markets missing from {book.bookmaker}
                                            </div>

                                            {event.missingSharpMarkets.map((missing) => (
                                              <div
                                                key={`${eventKey}_missing_${missing.marketType}`}
                                                style={missingSharpMarketStyle}
                                              >
                                                {formatMarketLabel(missing.marketType)} present on{" "}
                                                <strong>{missing.sharpBooksLabel}</strong>, NOT loaded on{" "}
                                                <strong>{book.bookmaker}</strong>.
                                              </div>
                                            ))}
                                          </div>
                                        ) : null}
                                      </>
                                    ) : null}
                                  </div>
                                );
                              })}
                            </div>
                          ) : null}
                        </div>
                      );
                    })}
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
const EV_LOADED_COVERAGE_SNAPSHOT_KEY = "EV_LOADED_COVERAGE_SNAPSHOT";

function writeEvLoadedCoverageSnapshot(coverage = {}) {
  if (typeof window === "undefined") return;

  try {
    const snapshot = {
      version: 1,
      writtenAt: new Date().toISOString(),
      bookCount: coverage.bookCount || 0,
      eventCount: coverage.eventCount || 0,
      marketCount: coverage.marketCount || 0,
      rowCount: coverage.rowCount || 0,
      books: (coverage.books || []).map((book) => ({
        bookmaker: book.bookmaker,
        rowCount: book.rowCount,
        sports: (book.sports || []).map((sport) => ({
          sport: sport.sport,
          rowCount: sport.rowCount,
          events: (sport.events || []).map((event) => ({
            eventName: event.eventName,
            rowCount: event.rowCount,
            marketTypes: (event.markets || []).map((market) => market.marketType),
            missingSharpMarkets: (event.missingSharpMarkets || []).map((missing) => ({
              marketType: missing.marketType,
              sharpBooks: missing.sharpBooks || [],
            })),
            missingExpectedMarkets: (event.missingExpectedMarkets || []).map((missing) => ({
              marketType: missing.marketType,
              reason: missing.reason || "expected_core_market",
            })),
            coverageMarkedComplete: event.coverageMarkedComplete === true,
            isThin: event.isThin === true,
          })),
        })),
      })),
    };

    localStorage.setItem(EV_LOADED_COVERAGE_SNAPSHOT_KEY, JSON.stringify(snapshot));
  } catch (err) {
    // ignore coverage snapshot write failures
  }
}

function buildCoverage(rows = []) {
  const bookMap = new Map();
  const uniqueEvents = new Set();
  const uniqueMarkets = new Set();
  const sharpMarketMap = buildSharpMarketMap(rows);
  const bookEventMarketMap = buildBookEventMarketMap(rows);

  for (const row of rows || []) {
    const bookmaker = clean(row.sportsbook || row.bookmaker || "Unknown Book");
    const eventName = getCoverageEventName(row);
    const sport = getCoverageSport(row, eventName);
    const marketType = clean(row.marketType || row.betType || "unknown_market");
    const isSharp = isCoverageSharpRow(row);
    const isTarget = !isSharp;

    if (!bookMap.has(bookmaker)) {
      bookMap.set(bookmaker, {
        bookmaker,
        sportsMap: new Map(),
        rowCount: 0,
      });
    }

    const book = bookMap.get(bookmaker);
    book.rowCount += 1;

    if (!book.sportsMap.has(sport)) {
      book.sportsMap.set(sport, {
        sport,
        eventsMap: new Map(),
        rowCount: 0,
      });
    }

    const sportBucket = book.sportsMap.get(sport);
    sportBucket.rowCount += 1;

    if (!sportBucket.eventsMap.has(eventName)) {
      sportBucket.eventsMap.set(eventName, {
        eventName,
        marketsMap: new Map(),
        rowCount: 0,
        targetRowCount: 0,
        sharpRowCount: 0,
        coverageMarkedComplete: false,
        coverageMarkedCompleteAt: "",
      });
    }

    const event = sportBucket.eventsMap.get(eventName);
    event.rowCount += 1;

    if (row.coverageMarkedComplete === true) {
      event.coverageMarkedComplete = true;
      event.coverageMarkedCompleteAt =
        row.coverageMarkedCompleteAt || event.coverageMarkedCompleteAt || "";
    }

    if (isTarget) event.targetRowCount += 1;
    if (isSharp) event.sharpRowCount += 1;

    if (!event.marketsMap.has(marketType)) {
      event.marketsMap.set(marketType, {
        marketType,
        rowCount: 0,
        targetRowCount: 0,
        sharpRowCount: 0,
        noSharpMatch: false,
      });
    }

    const market = event.marketsMap.get(marketType);
    market.rowCount += 1;

    if (isTarget) market.targetRowCount += 1;
    if (isSharp) market.sharpRowCount += 1;

    uniqueEvents.add(`${bookmaker}::${sport}::${eventName}`);
    uniqueMarkets.add(`${bookmaker}::${sport}::${eventName}::${marketType}`);
  }

  const books = Array.from(bookMap.values())
    .map((book) => {
      const sports = Array.from(book.sportsMap.values())
        .map((sport) => {
          const events = Array.from(sport.eventsMap.values())
            .map((event) => {
              const eventSharpMarkets = getSharpMarketsForEvent(
                sharpMarketMap,
                sport.sport,
                event.eventName
              );

              const markets = Array.from(event.marketsMap.values())
                .map((market) => {
                  const sharpBooks = getSharpBooksForMarket(
                    sharpMarketMap,
                    sport.sport,
                    event.eventName,
                    market.marketType
                  );

                  return {
                    ...market,
                    noSharpMatch: market.targetRowCount > 0 && sharpBooks.length === 0,
                    sharpBooks,
                    sharpBooksLabel: formatSharpBooksLabel(sharpBooks),
                  };
                })
                .sort((a, b) =>
                  formatMarketLabel(a.marketType).localeCompare(formatMarketLabel(b.marketType))
                );

              const marketCount = markets.length;
              const currentMarketTypes = new Set(markets.map((market) => market.marketType));
              const crossSportMarketTypes = getBookEventMarketsAcrossSports(
                bookEventMarketMap,
                book.bookmaker,
                event.eventName
              );

              const missingExpectedMarkets =
                event.coverageMarkedComplete
                  ? []
                  : buildExpectedMissingMarketsForCoverageEvent({
                      bookmaker: book.bookmaker,
                      sport: sport.sport,
                      markets,
                    });

              const missingSharpMarkets =
                event.coverageMarkedComplete
                  ? []
                  : event.targetRowCount > 0
                    ? Array.from(eventSharpMarkets.entries())
                        .filter(([marketType]) =>
                          !currentMarketTypes.has(marketType) &&
                          !crossSportMarketTypes.has(marketType)
                        )
                        .map(([marketType, sharpBooksSet]) => {
                          const sharpBooks = Array.from(sharpBooksSet).sort();

                          return {
                            marketType,
                            sharpBooks,
                            sharpBooksLabel: formatSharpBooksLabel(sharpBooks),
                          };
                        })
                        .sort((a, b) =>
                          formatMarketLabel(a.marketType).localeCompare(formatMarketLabel(b.marketType))
                        )
                    : [];

              return {
                eventName: event.eventName,
                rowCount: event.rowCount,
                markets,
                marketCount,
                missingSharpMarkets,
                missingExpectedMarkets,
                coverageMarkedComplete: event.coverageMarkedComplete === true,
                coverageMarkedCompleteAt: event.coverageMarkedCompleteAt || "",
                isThin: event.coverageMarkedComplete
                  ? false
                  : isThinEvent({ marketCount, rowCount: event.rowCount, markets }),
              };
            })
            .sort((a, b) => {
              if (a.isThin !== b.isThin) return a.isThin ? -1 : 1;
              return a.eventName.localeCompare(b.eventName);
            });

          return {
            sport: sport.sport,
            rowCount: sport.rowCount,
            events,
            eventCount: events.length,
            marketCount: events.reduce((sum, event) => sum + event.marketCount, 0),
          };
        })
        .sort((a, b) => a.sport.localeCompare(b.sport));

      return {
        bookmaker: book.bookmaker,
        rowCount: book.rowCount,
        sports,
        eventCount: sports.reduce((sum, sport) => sum + sport.eventCount, 0),
        marketCount: sports.reduce((sum, sport) => sum + sport.marketCount, 0),
      };
    })
    .sort((a, b) => a.bookmaker.localeCompare(b.bookmaker));

  return {
    books,
    bookCount: books.length,
    eventCount: uniqueEvents.size,
    marketCount: uniqueMarkets.size,
    rowCount: rows.length,
  };
}

function isThinEvent({ marketCount, rowCount, markets }) {
  if (marketCount <= 3) return true;
  if (rowCount <= 6) return true;

  const hasMainLines =
    markets.some((m) => m.marketType === "moneyline_2way" || m.marketType === "moneyline_3way") &&
    markets.some((m) => m.marketType === "spread") &&
    markets.some((m) => m.marketType === "total");

  if (hasMainLines && marketCount === 3) return true;

  return false;
}

function clean(value) {
  return String(value || "").trim();
}

function isCoverageSharpRow(row = {}) {
  return (
    row.isSharpSource === true ||
    String(row.batchRole || "").toLowerCase() === "fair_odds" ||
    String(row.role || "").toLowerCase() === "sharp"
  );
}

function buildBookEventMarketMap(rows = []) {
  const map = new Map();

  for (const row of rows || []) {
    const bookmaker = clean(row.sportsbook || row.bookmaker || "Unknown Book");
    const eventName = getCoverageEventName(row);
    const marketType = clean(row.marketType || row.betType || "unknown_market");

    if (!bookmaker || !eventName || !marketType) continue;

    const key = `${bookmaker}::${normalizeCoverageEventName(eventName).toLowerCase()}`;

    if (!map.has(key)) {
      map.set(key, new Set());
    }

    map.get(key).add(marketType);
  }

  return map;
}

function getBookEventMarketsAcrossSports(bookEventMarketMap, bookmaker, eventName) {
  const key = `${clean(bookmaker || "Unknown Book")}::${normalizeCoverageEventName(eventName).toLowerCase()}`;
  return bookEventMarketMap.get(key) || new Set();
}

function buildExpectedMissingMarketsForCoverageEvent({ bookmaker = "", sport, markets = [] } = {}) {
  const bookKey = String(bookmaker || "").trim().toLowerCase();
  const sportKey = String(sport || "").trim().toUpperCase();
  const marketTypes = new Set((markets || []).map((market) => String(market.marketType || "").trim()));

  function missingFromProfile(profile = [], reason = "expected_market") {
    return profile
      .filter((marketType) => !marketTypes.has(marketType))
      .map((marketType) => ({
        marketType,
        reason,
      }));
  }

  if (sportKey === "WNBA") {
    const hasAnyWnbaRows = marketTypes.size > 0;
    const hasAnyWnbaPlayerMarket = [
      "player_points",
      "player_rebounds",
      "player_assists",
      "player_threes",
      "player_pra",
      "player_points_rebounds",
      "player_points_assists",
      "player_rebounds_assists",
      "double_double",
      "triple_double",
    ].some((marketType) => marketTypes.has(marketType));

    if (!hasAnyWnbaRows) return [];

    const wnbaMainLines = ["moneyline_2way", "spread", "total"];
    const wnbaSimpleProps = [
      "player_points",
      "player_rebounds",
      "player_assists",
      "player_threes",
    ];

    const wnbaComboProps = [
      "player_pra",
      "player_points_rebounds",
      "player_points_assists",
      "player_rebounds_assists",
      "double_double",
      "triple_double",
    ];

    // Pinnacle often has main lines + simple prop O/U, but not the same combo menu.
    // Do not require combo props from Pinnacle by default.
    if (bookKey.includes("pinnacle")) {
      const profile = hasAnyWnbaPlayerMarket
        ? [...wnbaMainLines, ...wnbaSimpleProps]
        : wnbaMainLines;

      return missingFromProfile(profile, "expected_wnba_pinnacle_market");
    }

    // DraftKings/FanDuel/TheScore should be targeted toward the full WNBA profile.
    // If we only have main lines loaded, this asks for player-prop tabs.
    return missingFromProfile(
      [...wnbaMainLines, ...wnbaSimpleProps, ...wnbaComboProps],
      "expected_wnba_book_market"
    );
  }

  if (sportKey === "NBA") {
    const hasAnyBasketballPlayerProp = [
      "player_points",
      "player_rebounds",
      "player_assists",
      "player_threes",
      "player_pra",
      "player_points_rebounds",
      "player_points_assists",
      "player_rebounds_assists",
      "double_double",
      "triple_double",
    ].some((marketType) => marketTypes.has(marketType));

    if (!hasAnyBasketballPlayerProp) return [];

    return missingFromProfile(
      [
        "player_points",
        "player_rebounds",
        "player_assists",
        "player_threes",
      ],
      "expected_core_basketball_player_market"
    );
  }

  if (sportKey === "NHL") {
    const hasAnyNhlPlayerProp = [
      "player_shots_on_goal",
      "player_points",
      "player_assists",
      "player_goals",
      "player_saves",
    ].some((marketType) => marketTypes.has(marketType));

    if (!hasAnyNhlPlayerProp) return [];

    return missingFromProfile(
      [
        "player_shots_on_goal",
        "player_points",
        "player_assists",
      ],
      "expected_core_nhl_player_market"
    );
  }

  return [];
}


function buildSharpMarketMap(rows = []) {
  const map = new Map();

  for (const row of rows || []) {
    if (!isCoverageSharpRow(row)) continue;

    const bookmaker = clean(row.sportsbook || row.bookmaker || "Sharp");
    const eventName = getCoverageEventName(row);
    const sport = getCoverageSport(row, eventName);
    const marketType = clean(row.marketType || row.betType || "unknown_market");

    if (!sport || !eventName || !marketType) continue;

    const eventKey = `${sport}::${eventName}`;

    if (!map.has(eventKey)) {
      map.set(eventKey, new Map());
    }

    const eventMarkets = map.get(eventKey);

    if (!eventMarkets.has(marketType)) {
      eventMarkets.set(marketType, new Set());
    }

    eventMarkets.get(marketType).add(bookmaker);
  }

  return map;
}

function getSharpMarketsForEvent(sharpMarketMap, sport, eventName) {
  const key = `${clean(sport).toUpperCase()}::${normalizeCoverageEventName(eventName)}`;
  return sharpMarketMap.get(key) || new Map();
}

function getSharpBooksForMarket(sharpMarketMap, sport, eventName, marketType) {
  const eventMarkets = getSharpMarketsForEvent(sharpMarketMap, sport, eventName);
  return Array.from(eventMarkets.get(marketType) || []).sort();
}

function formatSharpBooksLabel(sharpBooks = []) {
  if (!sharpBooks.length) return "no sharp book";

  const unique = Array.from(new Set(sharpBooks)).sort();

  if (unique.length === 1) return unique[0];
  if (unique.length === 2) return `${unique[0]} & ${unique[1]}`;

  return `${unique.slice(0, -1).join(", ")} & ${unique[unique.length - 1]}`;
}

function getCoverageSport(row = {}, eventName = "") {
  const rawSport = clean(row.sport || row.league || "UNKNOWN").toUpperCase();
  const eventText = normalizeCoverageEventName(eventName || getCoverageEventName(row));
  const inferred = inferCoverageSportFromEvent(eventText);

  return inferred || rawSport || "UNKNOWN";
}

function inferCoverageSportFromEvent(eventName = "") {
  const text = clean(eventName).toLowerCase();

  if (!text) return "";

  const nbaTeams = [
    "atlanta hawks", "boston celtics", "brooklyn nets", "charlotte hornets", "chicago bulls",
    "cleveland cavaliers", "dallas mavericks", "denver nuggets", "detroit pistons", "golden state warriors",
    "houston rockets", "indiana pacers", "los angeles clippers", "los angeles lakers", "memphis grizzlies",
    "miami heat", "milwaukee bucks", "minnesota timberwolves", "new orleans pelicans", "new york knicks",
    "oklahoma city thunder", "orlando magic", "philadelphia 76ers", "phoenix suns", "portland trail blazers",
    "sacramento kings", "san antonio spurs", "toronto raptors", "utah jazz", "washington wizards"
  ];

  const wnbaTeams = [
    "atlanta dream", "chicago sky", "connecticut sun", "dallas wings", "golden state valkyries",
    "indiana fever", "las vegas aces", "los angeles sparks", "minnesota lynx", "new york liberty",
    "phoenix mercury", "portland fire", "seattle storm", "toronto tempo", "washington mystics"
  ];

  const nhlTeams = [
    "anaheim ducks", "boston bruins", "buffalo sabres", "calgary flames", "carolina hurricanes",
    "chicago blackhawks", "colorado avalanche", "columbus blue jackets", "dallas stars", "detroit red wings",
    "edmonton oilers", "florida panthers", "los angeles kings", "minnesota wild", "montreal canadiens",
    "nashville predators", "new jersey devils", "new york islanders", "new york rangers", "ottawa senators",
    "philadelphia flyers", "pittsburgh penguins", "san jose sharks", "seattle kraken", "st. louis blues",
    "tampa bay lightning", "toronto maple leafs", "utah hockey club", "utah mammoth", "vancouver canucks",
    "vegas golden knights", "washington capitals", "winnipeg jets"
  ];

  const mlbTeams = [
    "arizona diamondbacks", "atlanta braves", "baltimore orioles", "boston red sox", "chicago cubs",
    "chicago white sox", "cincinnati reds", "cleveland guardians", "colorado rockies", "detroit tigers",
    "houston astros", "kansas city royals", "los angeles angels", "los angeles dodgers", "miami marlins",
    "milwaukee brewers", "minnesota twins", "new york mets", "new york yankees", "athletics",
    "philadelphia phillies", "pittsburgh pirates", "san diego padres", "san francisco giants", "seattle mariners",
    "st. louis cardinals", "tampa bay rays", "texas rangers", "toronto blue jays", "washington nationals"
  ];

  if (nbaTeams.some((team) => text.includes(team))) return "NBA";
  if (wnbaTeams.some((team) => text.includes(team))) return "WNBA";
  if (nhlTeams.some((team) => text.includes(team))) return "NHL";
  if (mlbTeams.some((team) => text.includes(team))) return "MLB";

  return "";
}


function getCoverageEventName(row = {}) {
  const away = clean(row.awayTeam || row.awayTeamRaw || "");
  const home = clean(row.homeTeam || row.homeTeamRaw || "");

  if (away && home) {
    return `${normalizeCoverageTeamName(away)} @ ${normalizeCoverageTeamName(home)}`;
  }

  return normalizeCoverageEventName(
    row.eventLabelRaw || row.eventName || row.fixture || "Unknown Event"
  );
}

function normalizeCoverageEventName(value) {
  const text = clean(value).replace(/\s+/g, " ");

  if (!text.includes("@") && !/\svs\.?\s/i.test(text)) {
    return normalizeCoverageTeamName(text);
  }

  const parts = text
    .split(/\s@\s|\svs\.?\s/i)
    .map((part) => clean(part))
    .filter(Boolean);

  if (parts.length !== 2) return text;

  return `${normalizeCoverageTeamName(parts[0])} @ ${normalizeCoverageTeamName(parts[1])}`;
}

function normalizeCoverageTeamName(value) {
  const text = clean(value).replace(/\s+/g, " ");
  const lower = text.toLowerCase();

  const aliases = new Map([
    // NBA
    ["knicks", "New York Knicks"],
    ["ny knicks", "New York Knicks"],
    ["new york knicks", "New York Knicks"],

    ["hawks", "Atlanta Hawks"],
    ["atl hawks", "Atlanta Hawks"],
    ["atlanta hawks", "Atlanta Hawks"],

    ["celtics", "Boston Celtics"],
    ["bos celtics", "Boston Celtics"],
    ["boston celtics", "Boston Celtics"],

    ["76ers", "Philadelphia 76ers"],
    ["sixers", "Philadelphia 76ers"],
    ["phi 76ers", "Philadelphia 76ers"],
    ["philadelphia 76ers", "Philadelphia 76ers"],

    ["nuggets", "Denver Nuggets"],
    ["den nuggets", "Denver Nuggets"],
    ["denver nuggets", "Denver Nuggets"],

    ["timberwolves", "Minnesota Timberwolves"],
    ["min timberwolves", "Minnesota Timberwolves"],
    ["minnesota timberwolves", "Minnesota Timberwolves"],

    ["pistons", "Detroit Pistons"],
    ["det pistons", "Detroit Pistons"],
    ["detroit pistons", "Detroit Pistons"],

    ["magic", "Orlando Magic"],
    ["orl magic", "Orlando Magic"],
    ["orlando magic", "Orlando Magic"],

    ["cavaliers", "Cleveland Cavaliers"],
    ["cle cavaliers", "Cleveland Cavaliers"],
    ["cleveland cavaliers", "Cleveland Cavaliers"],

    ["raptors", "Toronto Raptors"],
    ["tor raptors", "Toronto Raptors"],
    ["toronto raptors", "Toronto Raptors"],

    ["lakers", "Los Angeles Lakers"],
    ["la lakers", "Los Angeles Lakers"],
    ["lal lakers", "Los Angeles Lakers"],
    ["los angeles lakers", "Los Angeles Lakers"],

    ["rockets", "Houston Rockets"],
    ["hou rockets", "Houston Rockets"],
    ["houston rockets", "Houston Rockets"],

    // WNBA
    ["atl dream", "Atlanta Dream"],
    ["atlanta dream", "Atlanta Dream"],
    ["chi sky", "Chicago Sky"],
    ["chicago sky", "Chicago Sky"],
    ["con sun", "Connecticut Sun"],
    ["ct sun", "Connecticut Sun"],
    ["connecticut sun", "Connecticut Sun"],
    ["dal wings", "Dallas Wings"],
    ["dallas wings", "Dallas Wings"],
    ["gs valkyries", "Golden State Valkyries"],
    ["gsv valkyries", "Golden State Valkyries"],
    ["golden state valkyries", "Golden State Valkyries"],
    ["ind fever", "Indiana Fever"],
    ["indiana fever", "Indiana Fever"],
    ["lv aces", "Las Vegas Aces"],
    ["lva aces", "Las Vegas Aces"],
    ["las vegas aces", "Las Vegas Aces"],
    ["la sparks", "Los Angeles Sparks"],
    ["los angeles sparks", "Los Angeles Sparks"],
    ["min lynx", "Minnesota Lynx"],
    ["minnesota lynx", "Minnesota Lynx"],
    ["ny liberty", "New York Liberty"],
    ["nyl liberty", "New York Liberty"],
    ["new york liberty", "New York Liberty"],
    ["pho mercury", "Phoenix Mercury"],
    ["phx mercury", "Phoenix Mercury"],
    ["phoenix mercury", "Phoenix Mercury"],
    ["por fire", "Portland Fire"],
    ["portland fire", "Portland Fire"],
    ["sea storm", "Seattle Storm"],
    ["seattle storm", "Seattle Storm"],
    ["tor tempo", "Toronto Tempo"],
    ["toronto tempo", "Toronto Tempo"],
    ["was mystics", "Washington Mystics"],
    ["wsh mystics", "Washington Mystics"],
    ["washington mystics", "Washington Mystics"],

    // NHL
    ["wild", "Minnesota Wild"],
    ["min wild", "Minnesota Wild"],
    ["minnesota wild", "Minnesota Wild"],

    ["avalanche", "Colorado Avalanche"],
    ["col avalanche", "Colorado Avalanche"],
    ["colorado avalanche", "Colorado Avalanche"],

    ["hurricanes", "Carolina Hurricanes"],
    ["car hurricanes", "Carolina Hurricanes"],
    ["carolina hurricanes", "Carolina Hurricanes"],

    ["flyers", "Philadelphia Flyers"],
    ["phi flyers", "Philadelphia Flyers"],
    ["philadelphia flyers", "Philadelphia Flyers"],

    ["canadiens", "Montreal Canadiens"],
    ["mtl canadiens", "Montreal Canadiens"],
    ["mon canadiens", "Montreal Canadiens"],
    ["montreal canadiens", "Montreal Canadiens"],

    ["sabres", "Buffalo Sabres"],
    ["buf sabres", "Buffalo Sabres"],
    ["buffalo sabres", "Buffalo Sabres"],

    ["bruins", "Boston Bruins"],
    ["bos bruins", "Boston Bruins"],
    ["boston bruins", "Boston Bruins"],

    ["rangers", "New York Rangers"],
    ["ny rangers", "New York Rangers"],
    ["nyr", "New York Rangers"],
    ["new york rangers", "New York Rangers"],

    ["islanders", "New York Islanders"],
    ["ny islanders", "New York Islanders"],
    ["nyi islanders", "New York Islanders"],
    ["new york islanders", "New York Islanders"],

    ["stars", "Dallas Stars"],
    ["dal stars", "Dallas Stars"],
    ["dallas stars", "Dallas Stars"],

    ["jets", "Winnipeg Jets"],
    ["wpg jets", "Winnipeg Jets"],
    ["winnipeg jets", "Winnipeg Jets"],

    ["oilers", "Edmonton Oilers"],
    ["edm oilers", "Edmonton Oilers"],
    ["edmonton oilers", "Edmonton Oilers"],

    ["ducks", "Anaheim Ducks"],
    ["ana ducks", "Anaheim Ducks"],
    ["anaheim ducks", "Anaheim Ducks"],

    ["penguins", "Pittsburgh Penguins"],
    ["pit penguins", "Pittsburgh Penguins"],
    ["pittsburgh penguins", "Pittsburgh Penguins"],

    ["lightning", "Tampa Bay Lightning"],
    ["tb lightning", "Tampa Bay Lightning"],
    ["tbl lightning", "Tampa Bay Lightning"],
    ["tampa bay lightning", "Tampa Bay Lightning"],

    ["panthers", "Florida Panthers"],
    ["fla panthers", "Florida Panthers"],
    ["florida panthers", "Florida Panthers"],

    ["capitals", "Washington Capitals"],
    ["wsh capitals", "Washington Capitals"],
    ["washington capitals", "Washington Capitals"],

    ["maple leafs", "Toronto Maple Leafs"],
    ["leafs", "Toronto Maple Leafs"],
    ["tor maple leafs", "Toronto Maple Leafs"],
    ["toronto maple leafs", "Toronto Maple Leafs"],

    ["devils", "New Jersey Devils"],
    ["nj devils", "New Jersey Devils"],
    ["njd devils", "New Jersey Devils"],
    ["new jersey devils", "New Jersey Devils"],

    ["kings", "Los Angeles Kings"],
    ["la kings", "Los Angeles Kings"],
    ["lak kings", "Los Angeles Kings"],
    ["los angeles kings", "Los Angeles Kings"],

    ["senators", "Ottawa Senators"],
    ["ott senators", "Ottawa Senators"],
    ["ottawa senators", "Ottawa Senators"],

    ["kraken", "Seattle Kraken"],
    ["sea kraken", "Seattle Kraken"],
    ["seattle kraken", "Seattle Kraken"],

    ["predators", "Nashville Predators"],
    ["nsh predators", "Nashville Predators"],
    ["nashville predators", "Nashville Predators"],

    ["blue jackets", "Columbus Blue Jackets"],
    ["cbj blue jackets", "Columbus Blue Jackets"],
    ["columbus blue jackets", "Columbus Blue Jackets"],

    ["red wings", "Detroit Red Wings"],
    ["det red wings", "Detroit Red Wings"],
    ["detroit red wings", "Detroit Red Wings"],

    ["blackhawks", "Chicago Blackhawks"],
    ["chi blackhawks", "Chicago Blackhawks"],
    ["chicago blackhawks", "Chicago Blackhawks"],

    ["sharks", "San Jose Sharks"],
    ["sj sharks", "San Jose Sharks"],
    ["san jose sharks", "San Jose Sharks"],

    ["blues", "St. Louis Blues"],
    ["st louis blues", "St. Louis Blues"],
    ["st. louis blues", "St. Louis Blues"],

    ["golden knights", "Vegas Golden Knights"],
    ["knights", "Vegas Golden Knights"],
    ["vegas", "Vegas Golden Knights"],
    ["vegas golden knights", "Vegas Golden Knights"],
  ]);

  return aliases.get(lower) || text;
}

function getRowLoadedAt(row = {}) {
  return (
    row.loadedAt ||
    row.parsedAt ||
    row.importedAt ||
    row.createdAt ||
    row.savedAt ||
    row.loadedAtIso ||
    row.parsedAtIso ||
    ""
  );
}

function formatCoverageTimestamp(value) {
  if (!value) return "";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  return `Loaded ${date.toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit",
  })}`;
}

function formatMarketLabel(value) {
  const text = String(value || "");

  const labels = {
    moneyline_2way: "Moneyline",
    moneyline_3way: "3-Way Moneyline",
    spread: "Spread",
    total: "Total",
    player_points: "Points",
    player_assists: "Assists",
    player_rebounds: "Rebounds",
    player_threes: "3-Pointers",
    player_pra: "PRA",
    player_points_rebounds: "Points + Rebounds",
    player_points_assists: "Points + Assists",
    player_rebounds_assists: "Rebounds + Assists",
    double_double: "Double-Double",
    triple_double: "Triple-Double",
    player_goals: "Goals",
    player_shots_on_goal: "Shots on Goal",
    player_saves: "Saves",
    player_power_play_points: "Power Play Points",
    goalie_goals_against: "Goals Against",
    player_blocked_shots: "Blocked Shots",
    anytime_goalscorer: "Anytime Goalscorer",
    first_goalscorer: "First Goalscorer",
    pitcher_strikeouts: "Pitcher Strikeouts",
    pitcher_hits_allowed: "Hits Allowed",
    pitcher_outs_recorded: "Pitcher Outs Recorded",
    pitcher_earned_runs_allowed: "Earned Runs Allowed",
    player_home_runs: "Home Runs",
    player_total_bases: "Total Bases",
    player_hits: "Hits",
    player_rbis: "RBIs",
    player_runs: "Runs",
  };

  return labels[text] || text.replace(/_/g, " ");
}

const sectionStyle = {
  background: "#fff",
  border: "1px solid #ddd",
  borderRadius: 12,
  padding: 16,
  marginBottom: 16,
};

const headerRowStyle = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
  flexWrap: "wrap",
  marginBottom: 12,
};

const h2Style = {
  margin: 0,
};

const subtleStyle = {
  color: "#666",
  fontSize: 12,
  marginTop: 4,
};

const headerButtonRowStyle = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  justifyContent: "flex-end",
};

const summaryPillStyle = {
  display: "inline-flex",
  alignItems: "center",
  border: "1px solid #d1d5db",
  borderRadius: 999,
  padding: "5px 9px",
  fontSize: 12,
  fontWeight: 800,
  background: "#f9fafb",
  color: "#374151",
};

const showThinButtonStyle = {
  border: "1px solid #86efac",
  borderRadius: 999,
  padding: "5px 10px",
  fontSize: 12,
  fontWeight: 900,
  background: "#ecfdf5",
  color: "#166534",
  cursor: "pointer",
};

const emptyThinStyle = {
  border: "1px dashed #d1d5db",
  borderRadius: 10,
  padding: 10,
  color: "#666",
  background: "#f9fafb",
  fontWeight: 700,
};

const bookCardStyle = {
  border: "1px solid #d1d5db",
  borderRadius: 10,
  padding: 10,
  background: "#fafafa",
};

const bookHeaderButtonStyle = {
  width: "100%",
  border: "none",
  background: "transparent",
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: 10,
  fontWeight: 900,
  cursor: "pointer",
  padding: 0,
  color: "#111827",
  textAlign: "left",
};

const coverageHeaderActionRowStyle = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  width: "100%",
};

const deleteCoverageButtonStyle = {
  border: "1px solid #fca5a5",
  borderRadius: 999,
  padding: "4px 8px",
  fontSize: 11,
  fontWeight: 900,
  background: "#fff",
  color: "#991b1b",
  cursor: "pointer",
  whiteSpace: "nowrap",
};

const coverageSportSelectWrapStyle = {
  display: "inline-flex",
  alignItems: "center",
  gap: 5,
  fontSize: 11,
  fontWeight: 900,
  color: "#374151",
  whiteSpace: "nowrap",
};

const coverageSportSelectStyle = {
  border: "1px solid #cbd5e1",
  borderRadius: 999,
  padding: "4px 7px",
  fontSize: 11,
  fontWeight: 900,
  background: "#fff",
  color: "#111827",
};

const bookMetaStyle = {
  color: "#4b5563",
  fontSize: 12,
  fontWeight: 800,
};

const sportCardStyle = {
  border: "1px solid #e5e7eb",
  borderRadius: 10,
  padding: 10,
  background: "#fff",
};

const sportHeaderStyle = {
  display: "flex",
  justifyContent: "space-between",
  gap: 10,
  flexWrap: "wrap",
  fontWeight: 900,
  marginBottom: 8,
};

const sportHeaderButtonStyle = {
  ...sportHeaderStyle,
  width: "100%",
  border: "none",
  background: "transparent",
  padding: 0,
  cursor: "pointer",
  color: "#111827",
  textAlign: "left",
};

const sportMetaStyle = {
  color: "#6b7280",
  fontSize: 12,
  fontWeight: 800,
};

const eventCardStyle = {
  borderWidth: 1,
  borderStyle: "solid",
  borderColor: "#e5e7eb",
  borderRadius: 10,
  padding: 9,
  background: "#f9fafb",
};

const thinEventStyle = {
  borderColor: "#f59e0b",
  background: "#fffbeb",
};

const eventHeaderButtonStyle = {
  width: "100%",
  border: "none",
  background: "transparent",
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: 10,
  cursor: "pointer",
  padding: 0,
  textAlign: "left",
  color: "#111827",
  fontWeight: 900,
};

const eventMetaWrapStyle = {
  display: "inline-flex",
  alignItems: "center",
  gap: 6,
  flexWrap: "wrap",
  justifyContent: "flex-end",
};

const thinBadgeStyle = {
  border: "1px solid #f59e0b",
  background: "#fef3c7",
  color: "#92400e",
  borderRadius: 999,
  padding: "2px 7px",
  fontSize: 11,
  fontWeight: 900,
};

const completeBadgeStyle = {
  border: "1px solid #86efac",
  background: "#dcfce7",
  color: "#166534",
  borderRadius: 999,
  padding: "2px 7px",
  fontSize: 11,
  fontWeight: 900,
};

const markCompleteButtonStyle = {
  border: "1px solid #86efac",
  borderRadius: 999,
  padding: "4px 8px",
  fontSize: 11,
  fontWeight: 900,
  background: "#ecfdf5",
  color: "#166534",
  cursor: "pointer",
  whiteSpace: "nowrap",
};

const eventTimestampStyle = {
  border: "1px solid #bfdbfe",
  background: "#eff6ff",
  color: "#1d4ed8",
  borderRadius: 999,
  padding: "2px 7px",
  fontSize: 11,
  fontWeight: 900,
};

const eventMetaStyle = {
  color: "#6b7280",
  fontSize: 12,
  fontWeight: 800,
};

const marketGridStyle = {
  marginTop: 8,
  display: "flex",
  flexWrap: "wrap",
  gap: 6,
};

const unmatchedMarketPillStyle = {
  border: "1px solid #fca5a5",
  background: "#fee2e2",
};

const noSharpBadgeStyle = {
  border: "1px solid #fca5a5",
  background: "#fff",
  color: "#991b1b",
  borderRadius: 999,
  padding: "1px 6px",
  fontSize: 10,
  fontWeight: 900,
};

const coverageWarningsStyle = {
  marginTop: 8,
  border: "1px solid #fecaca",
  background: "#fef2f2",
  color: "#991b1b",
  borderRadius: 10,
  padding: 8,
  display: "grid",
  gap: 4,
};

const coverageWarningsTitleStyle = {
  fontSize: 12,
  fontWeight: 900,
  marginBottom: 2,
};

const missingSharpMarketStyle = {
  fontSize: 12,
  fontWeight: 700,
  lineHeight: 1.35,
};

const marketPillStyle = {
  border: "1px solid #d1d5db",
  background: "#fff",
  borderRadius: 999,
  padding: "4px 8px",
  display: "inline-flex",
  alignItems: "center",
  gap: 6,
  fontSize: 12,
};

const marketNameStyle = {
  fontWeight: 900,
  color: "#111827",
};

const marketCountStyle = {
  color: "#6b7280",
  fontWeight: 800,
};
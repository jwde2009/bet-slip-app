"use client";

import { useMemo, useState } from "react";

export default function SavedPlacedParlaysLedgerPanel({
  savedPlacedParlays = [],
  savedLegUsageMap,
  onClearSavedParlays,
  onDeleteSavedParlay,
  onUpdateSavedParlay,
  onConfirmSavedParlayPlaced,
  onSetSavedParlayResult,
  formatSavedDateTime,
}) {
  const [savedCollapsed, setSavedCollapsed] = useState(true);
  const [performanceCollapsed, setPerformanceCollapsed] = useState(true);

  const stats = useMemo(
    () => buildLedgerStats(savedPlacedParlays),
    [savedPlacedParlays]
  );

  return (
    <div id="ev-section-saved-parlays" style={panelStyle}>
      <div style={headerStyle}>
        <div>
          <h3 style={{ margin: 0 }}>Saved / Placed Parlays</h3>
          <div style={subtleStyle}>
            Permanent ledger. Saved ideas do not count until Confirm Placed.
          </div>
        </div>

        <button
          type="button"
          onClick={() => onClearSavedParlays?.()}
          disabled={!savedPlacedParlays.length}
          style={{
            ...clearButtonStyle,
            opacity: savedPlacedParlays.length ? 1 : 0.55,
            cursor: savedPlacedParlays.length ? "pointer" : "not-allowed",
          }}
        >
          Clear Saved Parlays
        </button>
      </div>

      <div style={pnlSummaryStyle(stats.netProfitLoss)}>
        <div>
          <div style={pnlLabelStyle}>Placed Parlay Net P&L</div>
          <div style={pnlMainStyle(stats.netProfitLoss)}>
            {formatMoney(stats.netProfitLoss)}
          </div>
        </div>

        <div style={summaryGridStyle}>
          <SummaryPill label="Placed" value={stats.placedCount} />
          <SummaryPill label="Pending" value={stats.pendingCount} />
          <SummaryPill label="Won" value={stats.wonCount} />
          <SummaryPill label="Lost" value={stats.lostCount} />
          <SummaryPill label="Total Staked" value={formatMoney(stats.totalStaked)} />
          <SummaryPill label="ROI" value={formatPct(stats.roi)} />
        </div>
      </div>

      <div style={toggleRowStyle}>
        <button
          type="button"
          onClick={() => setSavedCollapsed((prev) => !prev)}
          style={toggleButtonStyle}
        >
          {savedCollapsed ? "Show Saved Parlays" : "Hide Saved Parlays"}
        </button>

        <button
          type="button"
          onClick={() => setPerformanceCollapsed((prev) => !prev)}
          style={toggleButtonStyle}
        >
          {performanceCollapsed ? "Show Performance Summary" : "Hide Performance Summary"}
        </button>
      </div>

      {!performanceCollapsed ? (
        <div style={performanceBoxStyle}>
          <h4 style={miniHeaderStyle}>Performance Summary</h4>

          <div style={summaryGridStyle}>
            <SummaryPill label="Saved Ideas" value={stats.savedIdeaCount} />
            <SummaryPill label="Confirmed Placed" value={stats.placedCount} />
            <SummaryPill label="Settled" value={stats.settledCount} />
            <SummaryPill label="Push/Void" value={stats.pushVoidCount} />
          </div>

          <div style={performanceTableStyle}>
            <div style={performanceHeaderRowStyle}>
              <strong>Book</strong>
              <strong>Placed</strong>
              <strong>Net</strong>
              <strong>ROI</strong>
            </div>

            {stats.byBook.length ? (
              stats.byBook.map((book) => (
                <div key={book.book} style={performanceRowStyle}>
                  <span>{book.book}</span>
                  <span>{book.count}</span>
                  <span style={book.net >= 0 ? profitStyle : lossStyle}>{formatMoney(book.net)}</span>
                  <span>{formatPct(book.roi)}</span>
                </div>
              ))
            ) : (
              <div style={emptyStyle}>No confirmed placed parlays yet.</div>
            )}
          </div>
        </div>
      ) : null}

      {!savedCollapsed ? (
        savedPlacedParlays.length === 0 ? (
          <div style={emptyStyle}>No saved placed parlays yet.</div>
        ) : (
          <div style={{ display: "grid", gap: 10 }}>
            {savedPlacedParlays.slice(0, 250).map((saved) => {
              const status = String(saved.status || "saved").toLowerCase();
              const isConfirmed = saved.confirmedPlaced === true || status !== "saved";
              const isSettled = ["won", "lost", "push", "void"].includes(status);
              const isPending = status === "placed" || status === "pending";
              const profitLoss = Number(saved.profitLoss || 0);

              return (
                <div key={saved.id} style={cardStyle(status)}>
                  <div style={cardTopStyle}>
                    <div style={{ minWidth: 0 }}>
                      <div style={cardTitleStyle}>
                        {saved.gradeTier || "Saved"} / {saved.playLabel || "Placed Parlay"}{" "}
                        <span style={statusPillStyle(status)}>{status}</span>
                      </div>

                      <div style={subtleStyle}>
                        Saved {formatSavedDateTime ? formatSavedDateTime(saved.savedAt) : saved.savedAt}
                        {getSavedParlayBook(saved) ? ` • Book: ${getSavedParlayBook(saved)}` : ""}
                        {saved.boostName ? ` • Boost: ${saved.boostName}` : ""}
                      </div>

                      {saved.actualBookSgpOddsAmerican ? (
                        <div style={subtleStyle}>
                          Actual SGP odds: {saved.actualBookSgpOddsAmerican}
                          {saved.actualBoostedSgpOddsAmerican ? ` / boosted ${saved.actualBoostedSgpOddsAmerican}` : ""}
                        </div>
                      ) : null}

                      {saved.placeabilityStatus ? (
                        <div style={subtleStyle}>
                          Placeability: {String(saved.placeabilityStatus).replace(/_/g, " ")}
                          {saved.placeabilityNotes ? ` - ${saved.placeabilityNotes}` : ""}
                        </div>
                      ) : null}
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteSavedParlay?.(saved.id)}
                      style={deleteButtonStyle}
                    >
                      Delete
                    </button>
                  </div>

                  <div style={editGridStyle}>
                    <label style={labelStyle}>
                      Book
                      <input
                        type="text"
                        value={getSavedParlayBook(saved)}
                        onChange={(event) =>
                          onUpdateSavedParlay?.(saved.id, {
                            bookmaker: event.target.value,
                            targetSportsbook: event.target.value,
                          })
                        }
                        style={inputStyle}
                      />
                    </label>

                    <label style={labelStyle}>
                      Stake
                      <input
                        type="number"
                        value={saved.placedStake ?? ""}
                        onChange={(event) =>
                          onUpdateSavedParlay?.(saved.id, {
                            placedStake: Number(event.target.value),
                          })
                        }
                        style={inputStyle}
                      />
                    </label>

                    <label style={labelStyle}>
                      Placed Odds
                      <input
                        type="number"
                        value={saved.placedOddsAmerican ?? saved.boostedParlayAmerican ?? ""}
                        onChange={(event) =>
                          onUpdateSavedParlay?.(saved.id, {
                            placedOddsAmerican: Number(event.target.value),
                          })
                        }
                        style={inputStyle}
                      />
                    </label>

                    <label style={labelStyle}>
                      Placed Date
                      <input
                        type="date"
                          value={saved.placedDate || getSavedParlayDefaultDate(saved)}
                        onChange={(event) =>
                          onUpdateSavedParlay?.(saved.id, { placedDate: event.target.value })
                        }
                        style={inputStyle}
                      />
                    </label>

                    <label style={labelStyle}>
                      Placeability
                      <select
                        value={saved.placeabilityStatus || "not_checked"}
                        onChange={(event) =>
                          onUpdateSavedParlay?.(saved.id, {
                            placeabilityStatus: event.target.value,
                          })
                        }
                        style={inputStyle}
                      >
                        <option value="not_checked">Not checked</option>
                        <option value="accepted">Accepted by book</option>
                        <option value="rejected">Rejected by book</option>
                        <option value="does_not_accept">Book does not accept</option>
                        <option value="could_not_build">Could not build</option>
                      </select>
                    </label>

                    <label style={labelStyle}>
                      Placeability Notes
                      <input
                        type="text"
                        value={saved.placeabilityNotes || ""}
                        placeholder="Rejected by book / accepted at +425 / etc."
                        onChange={(event) =>
                          onUpdateSavedParlay?.(saved.id, {
                            placeabilityNotes: event.target.value,
                          })
                        }
                        style={inputStyle}
                      />
                    </label>


                    <div style={pnlCardStyle(profitLoss)}>
                      <span style={pnlCardLabelStyle}>P&L</span>
                      <strong style={pnlCardValueStyle}>{formatMoney(profitLoss)}</strong>
                    </div>
                  </div>

                  <div style={buttonRowStyle}>
                    {!isConfirmed ? (
                      <button
                        type="button"
                        onClick={() => onConfirmSavedParlayPlaced?.(saved.id)}
                        style={confirmButtonStyle}
                      >
                        Confirm Placed
                      </button>
                    ) : null}

                    {isConfirmed && !isSettled ? (
                      <>
                        <button
                          type="button"
                          onClick={() => onSetSavedParlayResult?.(saved.id, "won")}
                          style={winButtonStyle}
                        >
                          Won
                        </button>
                        <button
                          type="button"
                          onClick={() => onSetSavedParlayResult?.(saved.id, "lost")}
                          style={lossButtonStyle}
                        >
                          Lost
                        </button>
                        <button
                          type="button"
                          onClick={() => onSetSavedParlayResult?.(saved.id, "push")}
                          style={neutralButtonStyle}
                        >
                          Push
                        </button>
                        <button
                          type="button"
                          onClick={() => onSetSavedParlayResult?.(saved.id, "void")}
                          style={neutralButtonStyle}
                        >
                          Void
                        </button>
                      </>
                    ) : null}

                    {isConfirmed || isSettled || isPending ? (
                      <button
                        type="button"
                        onClick={() => onSetSavedParlayResult?.(saved.id, "placed")}
                        style={neutralButtonStyle}
                      >
                        Back to Pending
                      </button>
                    ) : null}
                  </div>

                  <div style={legsWrapStyle}>
                    {(saved.legs || []).map((leg, idx) => (
                      <div key={`${saved.id}_${idx}`} style={legLineStyle}>
                        • {leg.eventName} — {formatSavedLeg(leg)}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : null}
    </div>
  );
}

function getSavedParlayBook(parlay = {}) {
  return (
    parlay.bookmaker ||
    parlay.targetSportsbook ||
    parlay.boostSportsbookLabel ||
    parlay.boostSportsbook ||
    parlay.legs?.[0]?.sportsbook ||
    ""
  );
}

function SummaryPill({ label, value }) {
  return (
    <div style={summaryPillStyle}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function buildLedgerStats(parlays = []) {
  const stats = {
    netProfitLoss: 0,
    totalStaked: 0,
    roi: null,
    placedCount: 0,
    pendingCount: 0,
    wonCount: 0,
    lostCount: 0,
    settledCount: 0,
    pushVoidCount: 0,
    savedIdeaCount: 0,
    byBook: [],
  };

  const byBook = new Map();

  for (const parlay of parlays || []) {
    const status = String(parlay.status || "saved").toLowerCase();
    const confirmed = parlay.confirmedPlaced === true || status !== "saved";

    if (!confirmed) {
      stats.savedIdeaCount += 1;
      continue;
    }

    stats.placedCount += 1;

    const stake = Number(parlay.placedStake || 0);
    const pnl = Number(parlay.profitLoss || 0);

    stats.totalStaked += Number.isFinite(stake) ? stake : 0;
    stats.netProfitLoss += Number.isFinite(pnl) ? pnl : 0;

    if (status === "placed" || status === "pending") stats.pendingCount += 1;
    if (status === "won") {
      stats.wonCount += 1;
      stats.settledCount += 1;
    }
    if (status === "lost") {
      stats.lostCount += 1;
      stats.settledCount += 1;
    }
    if (status === "push" || status === "void") {
      stats.pushVoidCount += 1;
      stats.settledCount += 1;
    }

    const book = getSavedParlayBook(parlay) || "Unknown";
    if (!byBook.has(book)) byBook.set(book, { book, count: 0, stake: 0, net: 0, roi: null });

    const bucket = byBook.get(book);
    bucket.count += 1;
    bucket.stake += Number.isFinite(stake) ? stake : 0;
    bucket.net += Number.isFinite(pnl) ? pnl : 0;
  }

  stats.roi = stats.totalStaked > 0 ? stats.netProfitLoss / stats.totalStaked : null;
  stats.byBook = Array.from(byBook.values())
    .map((item) => ({ ...item, roi: item.stake > 0 ? item.net / item.stake : null }))
    .sort((a, b) => b.net - a.net);

  return stats;
}

function getTodayDateInputValue() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function getSavedParlayDefaultDate(saved = {}) {
  const existing = String(saved?.placedDate || "").trim();
  if (existing) return existing;

  const savedAt = String(saved?.savedAt || "").trim();
  if (savedAt) {
    const date = new Date(savedAt);
    if (!Number.isNaN(date.getTime())) {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const day = String(date.getDate()).padStart(2, "0");

      return `${year}-${month}-${day}`;
    }
  }

  return getTodayDateInputValue();
}


function formatMoney(value) {
  const n = Number(value || 0);
  const sign = n > 0 ? "+" : "";
  return `${sign}$${n.toFixed(2)}`;
}

function formatPct(value) {
  if (!Number.isFinite(Number(value))) return "—";
  return `${(Number(value) * 100).toFixed(1)}%`;
}

function formatSavedLeg(leg) {
  if (leg?.displayLabel) return leg.displayLabel;

  const lineText =
    leg.lineValue !== null && leg.lineValue !== undefined && leg.lineValue !== ""
      ? ` ${leg.lineValue}`
      : "";

  const subject = String(leg.subjectName || "").trim();
  const selection = String(leg.selectionLabel || "").trim();
  const marketLabel = formatSavedMarketLabel(leg.marketType);

  const side = /\bover\b/i.test(selection)
    ? "Over"
    : /\bunder\b/i.test(selection)
      ? "Under"
      : /^yes$/i.test(selection)
        ? "Yes"
        : /^no$/i.test(selection)
          ? "No"
          : "";

  if (subject && side) {
    return `${subject} ${side}${lineText}${marketLabel ? ` ${marketLabel}` : ""}`.trim();
  }

  if (subject && lineText && isSavedPlayerPropMarket(leg.marketType)) {
    return `${subject} Over${lineText}${marketLabel ? ` ${marketLabel}` : ""}`.trim();
  }

  if (subject && selection && selection.toLowerCase() !== subject.toLowerCase()) {
    return `${subject} ${selection}${lineText}${marketLabel ? ` ${marketLabel}` : ""}`.trim();
  }

  if (selection) {
    return `${selection}${lineText}${marketLabel ? ` ${marketLabel}` : ""}`.trim();
  }

  return `${subject || "Leg"}${lineText}${marketLabel ? ` ${marketLabel}` : ""}`.trim();
}

function isSavedPlayerPropMarket(marketType = "") {
  const text = String(marketType || "").toLowerCase();

  return (
    text.startsWith("player_") ||
    text === "double_double" ||
    text === "triple_double"
  );
}

function formatSavedMarketLabel(marketType = "") {
  const labels = {
    player_points: "Points",
    player_assists: "Assists",
    player_rebounds: "Rebounds",
    player_threes: "Threes",
    player_pra: "PRA",
    player_points_rebounds: "Points + Rebounds",
    player_points_assists: "Points + Assists",
    player_rebounds_assists: "Rebounds + Assists",
    double_double: "Double-Double",
    triple_double: "Triple-Double",
    spread: "Spread",
    total: "Total",
    moneyline_2way: "Moneyline",
    moneyline_3way: "Moneyline",
  };

  return labels[String(marketType || "")] || String(marketType || "").replace(/_/g, " ");
}


const panelStyle = {
  border: "1px solid #d1d5db",
  borderRadius: 12,
  padding: 12,
  background: "#fff",
  marginTop: 16,
};

const headerStyle = {
  display: "flex",
  justifyContent: "space-between",
  gap: 12,
  flexWrap: "wrap",
  alignItems: "flex-start",
};

const subtleStyle = {
  color: "#6b7280",
  fontSize: 12,
  marginTop: 4,
};

function pnlSummaryStyle(net) {
  const positive = Number(net || 0) >= 0;
  return {
    marginTop: 12,
    border: positive ? "2px solid #86efac" : "2px solid #fca5a5",
    background: positive ? "#ecfdf5" : "#fef2f2",
    borderRadius: 14,
    padding: 14,
    display: "flex",
    justifyContent: "space-between",
    gap: 16,
    flexWrap: "wrap",
    alignItems: "center",
  };
}

const pnlLabelStyle = {
  fontSize: 12,
  fontWeight: 900,
  textTransform: "uppercase",
  color: "#475569",
  marginBottom: 2,
};

function pnlMainStyle(net) {
  return {
    fontSize: 34,
    lineHeight: 1,
    fontWeight: 1000,
    color: Number(net || 0) >= 0 ? "#166534" : "#991b1b",
  };
}

const profitStyle = {
  color: "#166534",
};

const lossStyle = {
  color: "#991b1b",
};

const summaryGridStyle = {
  display: "flex",
  flexWrap: "wrap",
  gap: 8,
};

const summaryPillStyle = {
  display: "inline-flex",
  gap: 6,
  alignItems: "center",
  border: "1px solid #d1d5db",
  background: "#fff",
  borderRadius: 999,
  padding: "6px 9px",
  fontSize: 12,
  fontWeight: 800,
};

const toggleRowStyle = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  marginTop: 10,
  marginBottom: 10,
};

const toggleButtonStyle = {
  border: "1px solid #bfdbfe",
  borderRadius: 999,
  padding: "6px 10px",
  background: "#eff6ff",
  color: "#1d4ed8",
  fontWeight: 900,
  cursor: "pointer",
};

const clearButtonStyle = {
  border: "1px solid #fca5a5",
  borderRadius: 999,
  padding: "6px 10px",
  background: "#fff",
  color: "#991b1b",
  fontWeight: 900,
};

const performanceBoxStyle = {
  border: "1px solid #e5e7eb",
  borderRadius: 10,
  padding: 10,
  background: "#f8fafc",
  marginBottom: 10,
};

const miniHeaderStyle = {
  margin: "0 0 8px",
};

const performanceTableStyle = {
  display: "grid",
  gap: 4,
  marginTop: 10,
};

const performanceHeaderRowStyle = {
  display: "grid",
  gridTemplateColumns: "1.5fr 0.6fr 0.8fr 0.6fr",
  gap: 8,
  fontSize: 12,
  color: "#374151",
};

const performanceRowStyle = {
  display: "grid",
  gridTemplateColumns: "1.5fr 0.6fr 0.8fr 0.6fr",
  gap: 8,
  fontSize: 12,
  borderTop: "1px solid #e5e7eb",
  paddingTop: 4,
};

const emptyStyle = {
  border: "1px dashed #d1d5db",
  borderRadius: 10,
  padding: 10,
  color: "#6b7280",
  background: "#f9fafb",
  fontWeight: 700,
};

function cardStyle(status) {
  const key = String(status || "saved").toLowerCase();
  const borderColor =
    key === "won"
      ? "#86efac"
      : key === "lost"
        ? "#fca5a5"
        : key === "void"
          ? "#9ca3af"
          : "#e5e7eb";

  const background =
    key === "won"
      ? "#f7fee7"
      : key === "lost"
        ? "#fff7f7"
        : key === "void"
          ? "repeating-linear-gradient(135deg, #f3f4f6 0px, #f3f4f6 8px, #e5e7eb 8px, #e5e7eb 16px)"
          : "#f9fafb";

  return {
    border: `1px solid ${borderColor}`,
    borderRadius: 12,
    padding: 12,
    background,
    opacity: key === "void" ? 0.82 : 1,
  };
}

const cardTopStyle = {
  display: "flex",
  justifyContent: "space-between",
  gap: 10,
  flexWrap: "wrap",
  alignItems: "flex-start",
};

const cardTitleStyle = {
  fontWeight: 900,
  color: "#111827",
};

function statusPillStyle(status) {
  const key = String(status || "saved").toLowerCase();
  const common = {
    borderRadius: 999,
    padding: "2px 7px",
    fontSize: 10,
    fontWeight: 900,
    marginLeft: 6,
    textTransform: "uppercase",
  };
  if (key === "won") return { ...common, border: "1px solid #86efac", background: "#dcfce7", color: "#166534" };
  if (key === "lost") return { ...common, border: "1px solid #fca5a5", background: "#fee2e2", color: "#991b1b" };
  if (key === "placed" || key === "pending") return { ...common, border: "1px solid #bfdbfe", background: "#eff6ff", color: "#1d4ed8" };
  if (key === "push" || key === "void") return { ...common, border: "1px solid #d1d5db", background: "#f3f4f6", color: "#374151" };
  return { ...common, border: "1px solid #fbbf24", background: "#fffbeb", color: "#92400e" };
}

const editGridStyle = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
  gap: 10,
  marginTop: 12,
  alignItems: "stretch",
};

const labelStyle = {
  display: "grid",
  gap: 3,
  fontSize: 11,
  fontWeight: 800,
  color: "#374151",
};

const inputStyle = {
  width: "100%",
  boxSizing: "border-box",
  border: "1px solid #cbd5e1",
  borderRadius: 8,
  padding: "8px 9px",
  fontSize: 12,
  background: "#fff",
};

function pnlCardStyle(value) {
  const n = Number(value || 0);
  return {
    border: n >= 0 ? "1px solid #86efac" : "1px solid #fca5a5",
    borderRadius: 10,
    padding: "8px 10px",
    display: "grid",
    gap: 2,
    background: n >= 0 ? "#ecfdf5" : "#fef2f2",
  };
}

const pnlCardLabelStyle = {
  fontSize: 11,
  fontWeight: 900,
  textTransform: "uppercase",
  color: "#475569",
};

const pnlCardValueStyle = {
  fontSize: 22,
  lineHeight: 1.1,
  fontWeight: 1000,
};

const buttonRowStyle = {
  display: "flex",
  gap: 8,
  flexWrap: "wrap",
  marginTop: 12,
};

const confirmButtonStyle = {
  border: "1px solid #86efac",
  background: "#dcfce7",
  color: "#166534",
  borderRadius: 999,
  padding: "6px 10px",
  fontWeight: 900,
  cursor: "pointer",
};

const winButtonStyle = {
  ...confirmButtonStyle,
};

const lossButtonStyle = {
  border: "1px solid #fca5a5",
  background: "#fee2e2",
  color: "#991b1b",
  borderRadius: 999,
  padding: "6px 10px",
  fontWeight: 900,
  cursor: "pointer",
};

const neutralButtonStyle = {
  border: "1px solid #d1d5db",
  background: "#fff",
  color: "#374151",
  borderRadius: 999,
  padding: "6px 10px",
  fontWeight: 900,
  cursor: "pointer",
};

const deleteButtonStyle = {
  border: "1px solid #fca5a5",
  background: "#fff",
  color: "#991b1b",
  borderRadius: 999,
  padding: "6px 10px",
  fontWeight: 900,
  cursor: "pointer",
};

const legsWrapStyle = {
  marginTop: 10,
  display: "grid",
  gap: 4,
};

const legLineStyle = {
  color: "#374151",
  fontSize: 12,
  fontWeight: 700,
};


  
import { americanToDecimal } from "../odds";

let nextId = 1;

function makeId() {
  return `score_row_${nextId++}`;
}

export function parseTheScoreText(rawText = "", context = {}) {
  if (!rawText || typeof rawText !== "string") return [];

  const lines = rawText
    .split("\n")
    .map(normalizeLine)
    .filter(Boolean);

  const sport = inferSport(lines, context);
  const rows = [];

  const detailEvent = findDetailEvent(lines);
  if (detailEvent) {
    const event = `${detailEvent.away} @ ${detailEvent.home}`;

    rows.push(...parseDetailMainLines(lines, detailEvent.startIndex, event, detailEvent.away, detailEvent.home, sport));
    rows.push(...parseDetailOuProps(lines, detailEvent.startIndex, event, sport));
    rows.push(...parseDetailPlusLadders(lines, detailEvent.startIndex, event, sport));
    rows.push(...parseDetailYesNoProps(lines, detailEvent.startIndex, event, sport));
  }

  if (rows.length === 0) {
    rows.push(...parseLandingGames(lines, sport));
  }

  if (rows.length === 0) {
    rows.push(...parseStructuredExport(lines, context));
  }

  rows.push(...parseTheScoreInlineComboOuBlocks(lines, context));

  return dedupeRows(rows);
}

function parseLandingGames(lines, sport) {
  const rows = [];

  for (let i = 0; i < lines.length - 13; i += 1) {
    if (isLiveMarker(lines[i]) || isLiveClockLine(lines[i])) continue;

    const away = lines[i];

    if (!isLikelyTeamName(away)) continue;

    // NBA-style scheduled row:
    // Team / record / spread / odds / O total / odds / money / Team / record / spread / odds / U total / odds / money
    const nbaHome = lines[i + 7];
    const awayMeta = lines[i + 1];
    const homeMeta = lines[i + 8];

    if (
      isLikelyTeamName(nbaHome) &&
      (looksLikeRecordLine(awayMeta) || isSkippableMetaLine(awayMeta)) &&
      (looksLikeRecordLine(homeMeta) || isSkippableMetaLine(homeMeta))
    ) {
      const parsed = {
        spreadA: parseSignedNumber(lines[i + 2]),
        spreadAOdds: parseAmericanOdds(lines[i + 3]),
        totalLineOver: parseTotalToken(lines[i + 4], "O"),
        totalOverOdds: parseAmericanOdds(lines[i + 5]),
        moneylineA: parseAmericanOdds(lines[i + 6]),
        spreadB: parseSignedNumber(lines[i + 9]),
        spreadBOdds: parseAmericanOdds(lines[i + 10]),
        totalLineUnder: parseTotalToken(lines[i + 11], "U"),
        totalUnderOdds: parseAmericanOdds(lines[i + 12]),
        moneylineB: parseAmericanOdds(lines[i + 13]),
      };

      if (
        parsed.spreadA !== null &&
        parsed.spreadAOdds !== null &&
        parsed.totalLineOver !== null &&
        parsed.totalOverOdds !== null &&
        parsed.moneylineA !== null &&
        parsed.spreadB !== null &&
        parsed.spreadBOdds !== null &&
        parsed.totalLineUnder !== null &&
        parsed.totalUnderOdds !== null &&
        parsed.moneylineB !== null
      ) {
        const event = `${away} @ ${nbaHome}`;
        rows.push(...buildMainRows(event, away, nbaHome, sport, {
          spreadA: parsed.spreadA,
          spreadAOdds: parsed.spreadAOdds,
          moneylineA: parsed.moneylineA,
          spreadB: parsed.spreadB,
          spreadBOdds: parsed.spreadBOdds,
          moneylineB: parsed.moneylineB,
          totalLine: parsed.totalLineOver,
          totalOverOdds: parsed.totalOverOdds,
          totalUnderOdds: parsed.totalUnderOdds,
        }));
        continue;
      }
    }

    // NHL-style scheduled row:
    // Team / spread / odds / O total / odds / money / Team / spread / odds / U total / odds / money
    const nhlHome = lines[i + 6];

    if (isLikelyTeamName(nhlHome)) {
      const parsed = {
        spreadA: parseSignedNumber(lines[i + 1]),
        spreadAOdds: parseAmericanOdds(lines[i + 2]),
        totalLineOver: parseTotalToken(lines[i + 3], "O"),
        totalOverOdds: parseAmericanOdds(lines[i + 4]),
        moneylineA: parseAmericanOdds(lines[i + 5]),
        spreadB: parseSignedNumber(lines[i + 7]),
        spreadBOdds: parseAmericanOdds(lines[i + 8]),
        totalLineUnder: parseTotalToken(lines[i + 9], "U"),
        totalUnderOdds: parseAmericanOdds(lines[i + 10]),
        moneylineB: parseAmericanOdds(lines[i + 11]),
      };

      if (
        parsed.spreadA !== null &&
        parsed.spreadAOdds !== null &&
        parsed.totalLineOver !== null &&
        parsed.totalOverOdds !== null &&
        parsed.moneylineA !== null &&
        parsed.spreadB !== null &&
        parsed.spreadBOdds !== null &&
        parsed.totalLineUnder !== null &&
        parsed.totalUnderOdds !== null &&
        parsed.moneylineB !== null
      ) {
        const event = `${away} @ ${nhlHome}`;
        rows.push(...buildMainRows(event, away, nhlHome, sport, {
          spreadA: parsed.spreadA,
          spreadAOdds: parsed.spreadAOdds,
          moneylineA: parsed.moneylineA,
          spreadB: parsed.spreadB,
          spreadBOdds: parsed.spreadBOdds,
          moneylineB: parsed.moneylineB,
          totalLine: parsed.totalLineOver,
          totalOverOdds: parsed.totalOverOdds,
          totalUnderOdds: parsed.totalUnderOdds,
        }));
        continue;
      }
    }
  }

  return rows;
}

function findDetailEvent(lines) {
  const startsIndex = lines.findIndex((line) => /^Starts In:?$/i.test(line));
  if (startsIndex !== -1) {
    for (let i = startsIndex - 12; i < startsIndex + 20 && i < lines.length; i += 1) {
      if (i < 0) continue;
      if (looksLikeInlineEvent(lines[i])) {
        const parts = splitInlineEvent(lines[i]);
        if (parts) {
          return {
            away: parts.away,
            home: parts.home,
            startIndex: Math.max(0, i - 20),
          };
        }
      }
    }
  }

  const inlineEventIdx = lines.findIndex((line) => looksLikeInlineEvent(line));
  if (inlineEventIdx !== -1) {
    const parts = splitInlineEvent(lines[inlineEventIdx]);
    if (parts) {
      return {
        away: parts.away,
        home: parts.home,
        startIndex: Math.max(0, inlineEventIdx - 20),
      };
    }
  }

  return null;
}

function parseDetailMainLines(lines, startIndex, event, away, home, sport) {
  const rows = [];
  const searchStart = Math.max(0, startIndex - 20);
  const mainIdx = findLineIndexAfter(lines, searchStart, /^Main Lines$/i);
  if (mainIdx === -1) return rows;

  function looksLikeMainLineHeader(value) {
    return /\bSpread\b/i.test(value) && /\bTotal\b/i.test(value) && /\bMoney\b/i.test(value);
  }

  function looksLikeNextMainLineSection(value) {
    const text = normalizeLine(value);

    return (
      /^3-Way Moneyline$/i.test(text) ||
      /^Alternate\b/i.test(text) ||
      /^Goals$/i.test(text) ||
      /^Shots On Goal$/i.test(text) ||
      /^Points$/i.test(text) ||
      /^First Goalscorer$/i.test(text) ||
      /^Period\b/i.test(text) ||
      /^Team To Score Next Goal$/i.test(text) ||
      /^Player\b/i.test(text) ||
      /^Game Props$/i.test(text)
    );
  }

  function findEventIndex() {
    for (let i = mainIdx; i < Math.min(lines.length, mainIdx + 60); i += 1) {
      if (sameText(lines[i], event)) return i;
    }

    return -1;
  }

  function findTeamIndexes(eventIdx) {
    const teamIndexes = [];

    for (let i = eventIdx + 1; i < Math.min(lines.length, eventIdx + 40); i += 1) {
      if (looksLikeNextMainLineSection(lines[i])) break;
      if (looksLikeMainLineHeader(lines[i])) continue;

      if (isPossibleTeamRef(lines[i])) {
        teamIndexes.push(i);
        if (teamIndexes.length >= 2) break;
      }
    }

    return teamIndexes;
  }

  function parseTeamBlock(teamIndex, nextTeamIndex, expectedTotalSide) {
    const hardStop =
      nextTeamIndex > teamIndex
        ? nextTeamIndex
        : Math.min(lines.length, teamIndex + 12);

    const slice = lines
      .slice(teamIndex + 1, hardStop)
      .map(normalizeLine)
      .filter(Boolean)
      .filter((line) => !looksLikeNextMainLineSection(line));

    let spreadLine = null;
    let spreadOdds = null;
    let totalLine = null;
    let totalOdds = null;
    let moneyline = null;

    for (let i = 0; i < slice.length; i += 1) {
      if (spreadLine === null) {
        const maybeSpread = parseSignedNumber(slice[i]);
        const maybeSpreadOdds = parseAmericanOdds(slice[i + 1]);

        if (maybeSpread !== null && maybeSpreadOdds !== null) {
          spreadLine = maybeSpread;
          spreadOdds = maybeSpreadOdds;
          i += 1;
          continue;
        }
      }

      if (totalLine === null) {
        const maybeTotal = parseTotalToken(slice[i], expectedTotalSide);
        const maybeTotalOdds = parseAmericanOdds(slice[i + 1]);

        if (maybeTotal !== null && maybeTotalOdds !== null) {
          totalLine = maybeTotal;
          totalOdds = maybeTotalOdds;
          i += 1;
          continue;
        }
      }

      if (moneyline === null) {
        const maybeMoneyline = parseAmericanOdds(slice[i]);

        if (maybeMoneyline !== null) {
          moneyline = maybeMoneyline;
        }
      }
    }

    return {
      spreadLine,
      spreadOdds,
      totalLine,
      totalOdds,
      moneyline,
    };
  }

  const eventIdx = findEventIndex();
  if (eventIdx === -1) return rows;

  const [teamAIdx, teamBIdx] = findTeamIndexes(eventIdx);
  if (teamAIdx === undefined || teamBIdx === undefined) return rows;

  const parsedA = parseTeamBlock(teamAIdx, teamBIdx, "O");
  const parsedB = parseTeamBlock(teamBIdx, -1, "U");

  if (
    parsedA.spreadLine !== null &&
    parsedA.spreadOdds !== null &&
    parsedA.totalLine !== null &&
    parsedA.totalOdds !== null &&
    parsedA.moneyline !== null &&
    parsedB.spreadLine !== null &&
    parsedB.spreadOdds !== null &&
    parsedB.totalLine !== null &&
    parsedB.totalOdds !== null &&
    parsedB.moneyline !== null
  ) {
    rows.push(...buildMainRows(event, away, home, sport, {
      spreadA: parsedA.spreadLine,
      spreadAOdds: parsedA.spreadOdds,
      moneylineA: parsedA.moneyline,
      spreadB: parsedB.spreadLine,
      spreadBOdds: parsedB.spreadOdds,
      moneylineB: parsedB.moneyline,
      totalLine: parsedA.totalLine,
      totalOverOdds: parsedA.totalOdds,
      totalUnderOdds: parsedB.totalOdds,
    }));
  }

  return rows;
}


function parseDetailOuProps(lines, startIndex, event, sport) {
  const rows = [];
  const searchStart = Math.max(0, startIndex - 40);

  const sectionMap = [
    ["Points (O/U)", "player_points"],
    ["Rebounds (O/U)", "player_rebounds"],
    ["Assists (O/U)", "player_assists"],
    ["3-Pointers Made (O/U)", "player_threes"],
    ["Pts + Reb + Ast (O/U)", "player_pra"],
    ["Reb + Ast (O/U)", "player_rebounds_assists"],
    ["Shots On Goal", "player_shots_on_goal"],
    ["Saves", "player_saves"],
    ["Hits", "player_hits"],
    ["Goals", "player_goals"],
    ["Assists", "player_assists"],
  ];

  for (const [header, marketType] of sectionMap) {
    const idx = findPropSectionIndex(lines, Math.max(0, startIndex - 40), header, event);
    if (idx === -1) continue;

    const end = findNextSectionIndex(lines, idx + 1);

    let i = idx + 1;
    while (i < end - 5) {
      const maybeEvent = lines[i];
      const maybePlayer = lines[i + 1];
      const maybeOver = lines[i + 2];
      const maybeOverOdds = lines[i + 3];
      const maybeUnder = lines[i + 4];
      const maybeUnderOdds = lines[i + 5];

      if (
        sameText(maybeEvent, event) &&
        looksLikePropSubject(maybePlayer) &&
        looksLikeOuToken(maybeOver, "O") &&
        parseAmericanOdds(maybeOverOdds) !== null &&
        looksLikeOuToken(maybeUnder, "U") &&
        parseAmericanOdds(maybeUnderOdds) !== null
      ) {
        const overLine = parseOuLine(maybeOver, "O");
        const underLine = parseOuLine(maybeUnder, "U");

        if (overLine !== null && underLine !== null && Math.abs(overLine - underLine) < 0.0001) {
          const player = normalizePropSubjectToPlayer(maybePlayer);

          rows.push(buildRow({
            sport,
            event,
            marketType,
            selection: `${player} Over`,
            lineValue: overLine,
            oddsAmerican: parseAmericanOdds(maybeOverOdds),
          }));
          rows.push(buildRow({
            sport,
            event,
            marketType,
            selection: `${player} Under`,
            lineValue: underLine,
            oddsAmerican: parseAmericanOdds(maybeUnderOdds),
          }));

          i += 6;
          continue;
        }
      }

      i += 1;
    }
  }

  return rows;
}

function parseDetailPlusLadders(lines, startIndex, event, sport) {
  const rows = [];
  const searchStart = Math.max(0, startIndex - 40);

  const sections = [
    ["Points", "player_points"],
    ["Rebounds", "player_rebounds"],
    ["Assists", "player_assists"],
    ["3-Pointers Made", "player_threes"],
    ["Pts + Reb + Ast", "player_pra"],
    ["Pts + Reb", "player_points_rebounds"],
    ["Pts + Ast", "player_points_assists"],
    ["Reb + Ast", "player_rebounds_assists"],
  ];

  for (const [header, marketType] of sections) {
    const idx = findPropSectionIndex(lines, searchStart, header, event);
    if (idx === -1) continue;

    const end = findNextSectionEndForLadders(lines, idx + 1);

    const thresholds = [];
    let thresholdIdx = -1;

    for (let i = idx + 1; i < end; i += 1) {
      if (!sameText(lines[i], event)) continue;

      const candidate = extractPlusTokensFromLine(lines[i + 1]);
      if (candidate.length) {
        thresholds.push(...candidate);
        thresholdIdx = i + 1;
        break;
      }
    }

    if (!thresholds.length || thresholdIdx === -1) continue;

    let i = thresholdIdx + 1;
    while (i < end) {
      const player = lines[i];

      if (!looksLikePlayerToken(player)) {
        i += 1;
        continue;
      }

      const odds = [];
      let j = i + 1;

      while (j < end && odds.length < thresholds.length) {
        const token = normalizeLine(lines[j]);

        if (/^Show more$/i.test(token)) break;
        if (sameText(token, event)) break;
        if ((isLikelySectionHeader(token) && !isComboHeader(token)) || isHardStopLine(token)) break;

        if (token === "--") {
          odds.push(null);
          j += 1;
          continue;
        }

        const american = parseAmericanOdds(token);
        if (american !== null) {
          odds.push(american);
        }

        j += 1;
      }

      for (let k = 0; k < Math.min(thresholds.length, odds.length); k += 1) {
        if (!Number.isFinite(odds[k])) continue;

        rows.push(buildRow({
          sport,
          event,
          marketType,
          selection: `${player} Over`,
          lineValue: thresholds[k] - 0.5,
          oddsAmerican: odds[k],
        }));
      }

      i = j;
    }
  }

  return dedupeRows(rows);
}

function parseDetailYesNoProps(lines, startIndex, event, sport) {
  const rows = [];
  const searchStart = Math.max(0, startIndex - 40);

  const sections = [
    ["Double Double", "double_double"],
    ["To Record A Double Double", "double_double"],
    ["Triple Double", "triple_double"],
    ["To Record A Triple Double", "triple_double"],
    ["Player Shutout", "player_shutout"],
    ["To Record A Shutout", "player_shutout"],
  ];

  for (const [header, marketType] of sections) {
    const idx = findLineIndexAfter(lines, searchStart, new RegExp(`^${escapeRegExp(header)}$`, "i"));
    if (idx === -1) continue;
    const end = findNextSectionIndex(lines, idx + 1);

    let i = idx + 1;
    while (i < end - 4) {
      const subject = lines[i];
      const yesLabel = lines[i + 1];
      const yesOdds = lines[i + 2];
      const noLabel = lines[i + 3];
      const noOdds = lines[i + 4];

      if (
        looksLikeLongSubject(subject) &&
        /^Yes$/i.test(yesLabel) &&
        parseAmericanOdds(yesOdds) !== null &&
        /^No$/i.test(noLabel) &&
        parseAmericanOdds(noOdds) !== null
      ) {
        rows.push(buildRow({
          sport,
          event,
          marketType,
          selection: normalizeSubject(subject, marketType),
          lineValue: null,
          oddsAmerican: parseAmericanOdds(yesOdds),
        }));
        i += 5;
        continue;
      }

      i += 1;
    }
  }

  return rows;
}

function parseStructuredExport(lines, context = {}) {
  const rows = [];

  let currentSport = String(context?.sport || "").toUpperCase() || "UNKNOWN";
  let currentEvent = String(context?.eventName || "").trim() || "Unknown Event";
  let currentMarket = "";
  let currentStructuredMainMarketIsJunk = false;

  for (const line of lines) {
    if (/^THESCORE_STRUCTURED_EXPORT$/i.test(line)) continue;

    const sportMatch = line.match(/^Sport:\s*(.+)$/i);
    if (sportMatch) {
      currentSport = normalizeLine(sportMatch[1]).toUpperCase();
      continue;
    }

    const eventMatch = line.match(/^Event:\s*(.+)$/i);
    if (eventMatch) {
      const nextEvent = normalizeLine(eventMatch[1]);
      currentEvent = isTheScoreFakeEventName(nextEvent)
        ? "__SKIP_THESCORE_FAKE_EVENT__"
        : nextEvent;
      currentMarket = "";
      currentStructuredMainMarketIsJunk = false;
      continue;
    }

    const marketMatch = line.match(/^Market:\s*(.+)$/i);
    if (marketMatch) {
      const nextMarket = normalizeLine(marketMatch[1]);

      if (!isTheScoreStructuredMainMarket(nextMarket)) {
        currentStructuredMainMarketIsJunk = false;
      } else if (/^spread$/i.test(nextMarket)) {
        currentStructuredMainMarketIsJunk = false;
      }

      currentMarket = nextMarket;
      continue;
    }

    if (isTheScoreFakeEventName(currentEvent)) {
      continue;
    }

    const ouMatch = line.match(/^(.+?)\s*\|\s*(OVER|UNDER)\s*\|\s*(\d+(?:\.\d+)?)\s*\|\s*((?:[+-]\d+)|EVEN)$/i);
    if (ouMatch) {
      const rawPlayer = normalizeLine(ouMatch[1]);
      const side = ouMatch[2].toLowerCase();
      const lineValue = Number(ouMatch[3]);
      const oddsAmerican = /^EVEN$/i.test(ouMatch[4]) ? 100 : Number(ouMatch[4]);

      const marketType = inferStructuredMarketType(currentMarket, "ou");
      const player = normalizeTheScoreStructuredPlayerName(rawPlayer, marketType);

      if (!player || !Number.isFinite(lineValue) || !Number.isFinite(oddsAmerican) || !marketType) {
        continue;
      }

      rows.push(buildRow({
        sport: currentSport,
        event: currentEvent,
        marketType,
        selection: `${player} ${side === "over" ? "Over" : "Under"}`,
        lineValue,
        oddsAmerican,
      }));

      continue;
    }

    const ladderMatch = line.match(/^(.+?)\s*\|\s*(\d+(?:\.\d+)?\+)\s*\|\s*((?:[+-]\d+)|EVEN)$/i);
    if (ladderMatch) {
      const player = normalizeLine(ladderMatch[1]);
      const threshold = Number(String(ladderMatch[2]).replace(/\+$/, ""));
      const oddsAmerican = /^EVEN$/i.test(ladderMatch[3]) ? 100 : Number(ladderMatch[3]);

      const marketType = inferStructuredMarketType(currentMarket, "ladder");

      if (!player || !Number.isFinite(threshold) || !Number.isFinite(oddsAmerican) || !marketType) {
        continue;
      }

      if (shouldSkipTheScoreStructuredLadder({
        sport: currentSport,
        marketType,
        marketName: currentMarket,
        player,
        threshold,
      })) {
        continue;
      }

      rows.push(buildRow({
        sport: currentSport,
        event: currentEvent,
        marketType,
        selection: `${player} Over`,
        lineValue: threshold - 0.5,
        oddsAmerican,
      }));

      continue;
    }

    const yesNoMatch = line.match(/^(.+?)\s*\|\s*(YES|NO)\s*\|\s*((?:[+-]\d+)|EVEN)$/i);
    if (yesNoMatch) {
      const player = normalizeLine(yesNoMatch[1]);
      const side = yesNoMatch[2].toUpperCase();
      const oddsAmerican = /^EVEN$/i.test(yesNoMatch[3]) ? 100 : Number(yesNoMatch[3]);

      const marketType = inferStructuredMarketType(currentMarket, "yesno");

      if (!player || !Number.isFinite(oddsAmerican) || !marketType) {
        continue;
      }

      rows.push(buildRow({
        sport: currentSport,
        event: currentEvent,
        marketType,
        selection: `${player} ${side === "YES" ? "Yes" : "No"}`,
        lineValue: null,
        oddsAmerican,
      }));

      continue;
    }

    const spreadMatch = line.match(/^(.+?)\s*\|\s*([+-]\d+(?:\.\d+)?)\s*\|\s*((?:[+-]\d+)|EVEN)$/i);
    if (spreadMatch && /^spread$/i.test(currentMarket)) {
      const team = normalizeLine(spreadMatch[1]);
      const lineValue = Number(spreadMatch[2]);
      const oddsAmerican = /^EVEN$/i.test(spreadMatch[3]) ? 100 : Number(spreadMatch[3]);

      if (isTheScoreFakeMainLineSelection(team)) {
        currentStructuredMainMarketIsJunk = true;
        continue;
      }

      if (!team || !Number.isFinite(lineValue) || !Number.isFinite(oddsAmerican)) {
        continue;
      }

      rows.push(buildRow({
        sport: currentSport,
        event: currentEvent,
        marketType: "spread",
        selection: team,
        lineValue,
        oddsAmerican,
      }));

      continue;
    }

    const totalMatch = line.match(/^(Over|Under)\s*\|\s*(\d+(?:\.\d+)?)\s*\|\s*((?:[+-]\d+)|EVEN)$/i);
    if (totalMatch && /^total$/i.test(currentMarket)) {
      if (currentStructuredMainMarketIsJunk) {
        continue;
      }

      const side = totalMatch[1];
      const lineValue = Number(totalMatch[2]);
      const oddsAmerican = /^EVEN$/i.test(totalMatch[3]) ? 100 : Number(totalMatch[3]);

      if (!Number.isFinite(lineValue) || !Number.isFinite(oddsAmerican)) {
        continue;
      }

      rows.push(buildRow({
        sport: currentSport,
        event: currentEvent,
        marketType: "total",
        selection: side,
        lineValue,
        oddsAmerican,
      }));

      continue;
    }

    const moneylineMatch = line.match(/^(.+?)\s*\|\s*((?:[+-]\d+)|EVEN)$/i);
    if (moneylineMatch && /^moneyline$/i.test(currentMarket)) {
      const team = normalizeLine(moneylineMatch[1]);
      const oddsAmerican = /^EVEN$/i.test(moneylineMatch[2]) ? 100 : Number(moneylineMatch[2]);

      if (isTheScoreFakeMainLineSelection(team)) {
        currentStructuredMainMarketIsJunk = true;
        continue;
      }

      if (!team || !Number.isFinite(oddsAmerican)) {
        continue;
      }

      rows.push(buildRow({
        sport: currentSport,
        event: currentEvent,
        marketType: "moneyline_2way",
        selection: team,
        lineValue: null,
        oddsAmerican,
      }));

      continue;
    }
  }

  return rows;
}

function shouldSkipTheScoreStructuredLadder({ sport = "", marketType = "", marketName = "", player = "", threshold = null } = {}) {
  const sportKey = String(sport || "").trim().toUpperCase();
  const marketKey = String(marketType || "").trim();

  // Default safety: basketball ladders create massive row counts and are
  // mostly alternate/milestone thresholds. Keep O/U and Yes/No rows instead.
  if (sportKey === "NBA" || sportKey === "WNBA") {
    return [
      "player_points",
      "player_rebounds",
      "player_assists",
      "player_threes",
      "player_pra",
      "player_points_rebounds",
      "player_points_assists",
      "player_rebounds_assists",
    ].includes(marketKey);
  }

  return false;
}

function parseTheScoreInlineComboOuBlocks(lines = [], context = {}) {
  const rows = [];
  const normalizedLines = (lines || []).map(normalizeLine).filter(Boolean);

  const marketMap = new Map([
    ["pts + reb + ast (o/u)", "player_pra"],
    ["pts + reb + ast o/u", "player_pra"],
    ["player pts + reb + ast", "player_pra"],
    ["pts + reb (o/u)", "player_points_rebounds"],
    ["pts + reb o/u", "player_points_rebounds"],
    ["player pts + reb", "player_points_rebounds"],
    ["pts + ast (o/u)", "player_points_assists"],
    ["pts + ast o/u", "player_points_assists"],
    ["player pts + ast", "player_points_assists"],
    ["reb + ast (o/u)", "player_rebounds_assists"],
    ["reb + ast o/u", "player_rebounds_assists"],
    ["player reb + ast", "player_rebounds_assists"],
  ]);

  let currentMarketType = "";

  for (let i = 0; i < normalizedLines.length - 5; i += 1) {
    const line = normalizedLines[i];
    const key = line.toLowerCase();

    if (marketMap.has(key)) {
      currentMarketType = marketMap.get(key);
      continue;
    }

    if (!currentMarketType) continue;

    if (isTheScoreInlineComboStopLine(line)) {
      currentMarketType = "";
      continue;
    }

    if (!isTheScoreEventLine(line)) continue;

    const event = line;
    const player = normalizedLines[i + 1];
    const overLine = parseTheScoreOuToken(normalizedLines[i + 2], "O");
    const overOdds = parseAmericanOdds(normalizedLines[i + 3]);
    const underLine = parseTheScoreOuToken(normalizedLines[i + 4], "U");
    const underOdds = parseAmericanOdds(normalizedLines[i + 5]);

    if (
      !looksLikeTheScoreComboPlayerName(player) ||
      overLine === null ||
      underLine === null ||
      Math.abs(overLine - underLine) > 0.0001 ||
      overOdds === null ||
      underOdds === null
    ) {
      continue;
    }

    rows.push(
      buildRow({
        sport: inferTheScoreSportFromEventOrContext(event, context),
        event,
        marketType: currentMarketType,
        selection: `${player} Over`,
        lineValue: overLine,
        oddsAmerican: overOdds,
      })
    );

    rows.push(
      buildRow({
        sport: inferTheScoreSportFromEventOrContext(event, context),
        event,
        marketType: currentMarketType,
        selection: `${player} Under`,
        lineValue: underLine,
        oddsAmerican: underOdds,
      })
    );

    i += 5;
  }

  return rows;
}

function isTheScoreEventLine(value = "") {
  const text = normalizeLine(value);
  return /^[A-Za-z0-9.' -]+ @ [A-Za-z0-9.' -]+$/.test(text);
}

function parseTheScoreOuToken(value = "", expectedSide = "") {
  const text = normalizeLine(value);
  const match = text.match(/^([OU])\s*(\d+(?:\.\d+)?)$/i);

  if (!match) return null;
  if (expectedSide && match[1].toUpperCase() !== String(expectedSide).toUpperCase()) return null;

  const parsed = Number(match[2]);
  return Number.isFinite(parsed) ? parsed : null;
}

function looksLikeTheScoreComboPlayerName(value = "") {
  const text = normalizeLine(value);

  if (!text) return false;
  if (isTheScoreEventLine(text)) return false;
  if (/^(OVER|UNDER|O|U|Show more|Show less)$/i.test(text)) return false;
  if (isTheScoreInlineComboStopLine(text)) return false;

  // Allows abbreviated names like V. Wembanyama, S. Gilgeous-Alexander,
  // Jal. Williams, Cas. Wallace, etc.
  return /^[A-Z][A-Za-z.'-]*(?:\s+[A-Z][A-Za-z.'-]*)+$/.test(text);
}

function isTheScoreInlineComboStopLine(value = "") {
  const text = normalizeLine(value);

  return (
    /^(Popular|Player Points|Player Rebounds|Player Assists|Player Threes|Player Combos|Player Defense|Half|Game Props|Specials)$/i.test(text) ||
    /^(Double Double|Triple Double|Pts \+ Reb \+ Ast|Pts \+ Reb|Pts \+ Ast|Reb \+ Ast)$/i.test(text) ||
    /^(To Record|Alternate|Alt |Bet on |Verifying location|ABOUT|Register|All Sports|Promotions|Support|Back to top|Betslip)/i.test(text)
  );
}

function inferTheScoreSportFromEventOrContext(event = "", context = {}) {
  if (context?.sport) return String(context.sport).toUpperCase();

  const text = normalizeLine(event).toLowerCase();

  if (
    /spurs|thunder|knicks|cavaliers|celtics|pacers|bucks|heat|lakers|nuggets|timberwolves|suns|warriors|mavericks|clippers|hawks|magic|hornets|raptors|pistons|rockets|76ers|bulls|nets|jazz|kings|pelicans|trail blazers/.test(text)
  ) {
    return "NBA";
  }

  if (
    /dream|sky|sun|wings|valkyries|fever|aces|sparks|lynx|liberty|mercury|storm|mystics/.test(text)
  ) {
    return "WNBA";
  }

  return "NBA";
}


function isTheScoreStructuredMainMarket(value = "") {
  return /^(spread|total|moneyline)$/i.test(normalizeLine(value));
}

function isTheScoreFakeEventName(value = "") {
  const text = normalizeLine(value);

  if (!text || text === "__SKIP_THESCORE_FAKE_EVENT__") return true;

  return (
    /\bTo Record A Double Double\b/i.test(text) ||
    /\bTo Record A Triple Double\b/i.test(text) ||
    /^Race To\b/i.test(text) ||
    /\bRace To\b/i.test(text) ||
    /\bFirst Basket\b/i.test(text) ||
    /\bFirst Field Goal\b/i.test(text) ||
    /\bFirst Player\b/i.test(text) ||
    /\bMethod Of\b/i.test(text) ||
    /\bCorrect Score\b/i.test(text) ||
    /\bWinning Margin\b/i.test(text)
  );
}

function isTheScoreFakeMainLineSelection(value = "") {
  const text = normalizeLine(value);

  return (
    isTheScoreFakeEventName(text) ||
    /\bTotal Goals\b/i.test(text) ||
    /\bTotal Saves\b/i.test(text) ||
    /\bTotal Shots\b/i.test(text) ||
    /\bTotal Points\b/i.test(text) ||
    /\bTo Record A Double Double\b/i.test(text) ||
    /\bTo Record A Triple Double\b/i.test(text) ||
    /^Race To\b/i.test(text)
  );
}

function normalizeTheScoreStructuredPlayerName(value = "", marketType = "") {
  const text = normalizeLine(value);
  const market = String(marketType || "").trim();

  if (
    market === "player_pra" ||
    market === "player_points_rebounds" ||
    market === "player_points_assists" ||
    market === "player_rebounds_assists"
  ) {
    return text
      .replace(/\s+Total\s+Points,\s*Rebounds\s+And\s+Assists$/i, "")
      .replace(/\s+Total\s+Points\s+And\s+Rebounds$/i, "")
      .replace(/\s+Total\s+Points\s+And\s+Assists$/i, "")
      .replace(/\s+Total\s+Rebounds\s+And\s+Assists$/i, "")
      .trim();
  }

  return text;
}

function inferStructuredMarketType(header, mode = "") {
  const text = normalizeLine(header).toLowerCase();

  if (text === "points (o/u)" || text === "points") return "player_points";
  if (text === "rebounds (o/u)" || text === "rebounds") return "player_rebounds";
  if (text === "assists (o/u)" || text === "assists") return "player_assists";
  if (text === "3-pointers made (o/u)" || text === "3-pointers made") return "player_threes";
  if (text === "pts + reb + ast (o/u)" || text === "pts + reb + ast") return "player_pra";
  if (text === "pts + reb (o/u)" || text === "pts + reb") return "player_points_rebounds";
  if (text === "pts + ast (o/u)" || text === "pts + ast") return "player_points_assists";
  if (text === "reb + ast (o/u)" || text === "reb + ast") return "player_rebounds_assists";
  if (text === "double double") return "double_double";
  if (text === "triple double") return "triple_double";

  if (text === "shots on goal") return "player_shots_on_goal";
  if (text === "goals") return "player_goals";
  if (text === "saves") return "player_saves";
  if (text === "player shutout") return "player_shutout";
  if (text === "power play points") return "player_power_play_points";
  if (text === "hits") return "player_hits";
  if (text === "points/assists") return "player_points_assists";

  if (text === "pitcher strikeouts") return "pitcher_strikeouts";
  if (text === "pitcher strikeouts (o/u)") return "pitcher_strikeouts";
  if (text === "outs recorded (o/u)") return "pitcher_outs_recorded";
  if (text === "hits allowed (o/u)") return "pitcher_hits_allowed";
  if (text === "earned runs allowed (o/u)") return "pitcher_earned_runs_allowed";
  if (text === "walks allowed (o/u)") return "pitcher_walks_allowed";

  if (text === "home runs") return "player_home_runs";
  if (text === "home runs (o/u)") return "player_home_runs";
  if (text === "rbis") return "player_rbis";
  if (text === "rbis (o/u)") return "player_rbis";
  if (text === "runs scored") return "player_runs";
  if (text === "runs scored (o/u)") return "player_runs";
  if (text === "total bases") return "player_total_bases";
  if (text === "total bases (o/u)") return "player_total_bases";
  if (text === "hits (o/u)") return "player_hits";

  return "";
}

function buildMainRows(event, away, home, sport, parsed) {
  return [
    buildRow({ sport, event, marketType: "spread", selection: away, lineValue: parsed.spreadA, oddsAmerican: parsed.spreadAOdds }),
    buildRow({ sport, event, marketType: "moneyline_2way", selection: away, lineValue: null, oddsAmerican: parsed.moneylineA }),
    buildRow({ sport, event, marketType: "total", selection: "Over", lineValue: parsed.totalLine, oddsAmerican: parsed.totalOverOdds }),
    buildRow({ sport, event, marketType: "spread", selection: home, lineValue: parsed.spreadB, oddsAmerican: parsed.spreadBOdds }),
    buildRow({ sport, event, marketType: "moneyline_2way", selection: home, lineValue: null, oddsAmerican: parsed.moneylineB }),
    buildRow({ sport, event, marketType: "total", selection: "Under", lineValue: parsed.totalLine, oddsAmerican: parsed.totalUnderOdds }),
  ];
}

function inferSport(lines, context) {
  if (context?.sport) return String(context.sport).toUpperCase();

  const text = lines.slice(0, 220).join(" ");

  if (/The Score NHL|NHL Landing Page|Game Page – Main|Game Page – Shots on Goal|Game Page – Goals|Game Page – Points \/ Assists|Game Page – Saves|Shots On Goal|Goalie\/Defense|SEA Kraken|COL Avalanche|MTL Canadiens|TB Lightning|OTT Senators|CAR Hurricanes|Vegas Golden Knights|Colorado Avalanche|Montreal Canadiens|Carolina Hurricanes/i.test(text)) {
    return "NHL";
  }

  if (/The Score NBA|NBA Landing Page|NBA|New York Knicks|NY Knicks|Cleveland Cavaliers|CLE Cavaliers|Oklahoma City Thunder|OKC Thunder|San Antonio Spurs|SA Spurs|Los Angeles Lakers|LA Lakers|Boston Celtics|Charlotte Hornets|Orlando Magic|Dallas Mavericks|Denver Nuggets|Minnesota Timberwolves|Golden State Warriors|Phoenix Suns|Atlanta Hawks|Houston Rockets|Philadelphia 76ers|Portland Trail Blazers/i.test(text)) {
    return "NBA";
  }

  if (/The Score WNBA|WNBA Landing Page|WNBA|Atlanta Dream|ATL Dream|Chicago Sky|Connecticut Sun|CON Sun|Dallas Wings|DAL Wings|Golden State Valkyries|GS Valkyries|Indiana Fever|Las Vegas Aces|Los Angeles Sparks|Minnesota Lynx|New York Liberty|NY Liberty|Phoenix Mercury|PHX Mercury|PHO Mercury|Portland Fire|Seattle Storm|Toronto Tempo|Washington Mystics|WAS Mystics/i.test(text)) {
    return "WNBA";
  }

  if (/MLB/i.test(text)) return "MLB";
  return "UNKNOWN";
}

function normalizeLine(value) {
  return String(value || "")
    .replace(/−|\u2212|âˆ’/g, "-")
    .replace(/\u00A0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function splitInlineEvent(value) {
  const text = normalizeLine(value);
  const parts = text.split(/\s@\s/);
  if (parts.length !== 2) return null;
  return { away: parts[0].trim(), home: parts[1].trim() };
}

function looksLikeInlineEvent(value) {
  const parts = splitInlineEvent(value);
  return !!(parts && parts.away && parts.home);
}

function isLikelyTeamName(value) {
  const text = normalizeLine(value);
  if (!text || !/[A-Za-z]/.test(text)) return false;
  if (/^\d+$/.test(text)) return false;
  if (/^\d{1,2}:\d{2}$/.test(text)) return false;
  if (/^[+-]?\d+(\.\d+)?$/.test(text)) return false;
  if (/^[OU]\s*\d+(\.\d+)?$/i.test(text)) return false;
  if (/^(NBA|NHL|Lines|Futures|Series|See All|Hot Props|Popular|Player Points|Player Rebounds|Player Assists|Player Threes|Player Combos|Player Defense|Quarter|Half|Game Props|Specials|Featured Parlays|Main Lines|Alternate Game Spread|Alternate Total Points|Player To Score The First Basket \(Incl\. Free Throws\)|Goalscorer|Shots On Goal|Points\/Assists|Goalie\/Defense|Periods|Main|Money|Spread|Total|LIVE|Today|Tomorrow)$/i.test(text)) return false;
  if (/\b(Add To Betslip|bets placed|pays)\b/i.test(text)) return false;
  if (looksLikeInlineEvent(text)) return false;
  if (looksLikeRecordLine(text)) return false;
  return true;
}

function looksLikePlayerToken(value) {
  const text = normalizeLine(value);
  return /^[A-Z][A-Za-z'.-]{0,10}(?:\s[A-Z][A-Za-z'.-]{1,15}){0,2}$/.test(text) && !looksLikeInlineEvent(text);
}

function expandPlayerToken(value) {
  return normalizeLine(value);
}

function looksLikeLongSubject(value) {
  const text = normalizeLine(value);
  return /[A-Za-z]/.test(text) && !looksLikeInlineEvent(text) && !isLikelySectionHeader(text);
}

function normalizeSubject(value, marketType) {
  const text = normalizeLine(value);
  if (marketType === "double_double") return text.replace(/\s+To Record A Double Double$/i, "");
  if (marketType === "triple_double") return text.replace(/\s+To Record A Triple Double$/i, "");
  if (marketType === "player_shutout") return text.replace(/\s+To Record A Shutout$/i, "");
  return text;
}

function looksLikeRecordLine(value) {
  const text = normalizeLine(value);
  return /^\d{1,2}-\d{1,2}(?:-\d{1,2})?,/.test(text) || /^\d{1,2}-\d{1,2}(?:-\d{1,2})?$/.test(text);
}

function isSkippableMetaLine(value) {
  const text = normalizeLine(value);
  return /^([A-Z][a-z]{2}\s\d{1,2},\s\d{4}\s·\s\d{1,2}:\d{2}\s(?:AM|PM)|R\d, Game \d:|East Play-In Tournament|West Play-In Tournament)$/i.test(text);
}

function isPossibleTeamRef(value) {
  const text = normalizeLine(value);
  return /^[A-Z]{2,4}\s[A-Za-z]+$/i.test(text) || isLikelyTeamName(text);
}

function isSkippableLine(value) {
  const text = normalizeLine(value);
  return (
    /^Starts In:?$/i.test(text) ||
    /^\d{1,2}:\d{2}:\d{2}$/.test(text) ||
    /^\d{1,2}:\d{2}$/.test(text) ||
    /^(today|tomorrow)$/i.test(text) ||
    isLikelySectionHeader(text) ||
    looksLikeRecordLine(text) ||
    /^Apr \d{1,2}$/i.test(text) ||
    /^\d{1,2}:\d{2}\s*(am|pm)$/i.test(text)
  );
}

function isLikelySectionHeader(value) {
  const text = normalizeLine(value);

  // 🚫 EXCLUDE combo headers
  if (isComboHeader(text)) return false;

  return /^(Lines|Futures|Series|Popular|Player Points|Player Rebounds|Player Assists|Player Threes|Player Combos|Player Defense|Quarter|Half|Game Props|Specials|Featured Parlays|Main Lines|Alternate Game Spread|Alternate Total Points|Points|Rebounds|Assists|3-Pointers Made|Points \(O\/U\)|Rebounds \(O\/U\)|Assists \(O\/U\)|3-Pointers Made \(O\/U\)|Pts \+ Reb \+ Ast \(O\/U\)|Reb \+ Ast \(O\/U\)|Goalscorer|Shots On Goal|First To 5 Shots On Goal|Points\/Assists|Goalie\/Defense|Periods|Goals|Assists|Power Play Points|Saves|Hits|Player Shutout|Betting News|See All|Hot Props|Moving On|Series Specials|Playoff Specials)$/i.test(text);
}

function isComboHeader(value) {
  const text = normalizeLine(value);

  return /^(Pts \+ Reb \+ Ast|Pts \+ Reb|Pts \+ Ast|Reb \+ Ast|Double Double|To Record A Double Double|Triple Double|To Record A Triple Double)$/i.test(text);
}

function findPropSectionIndex(lines, startIndex, header, event) {
  const pattern = new RegExp(`^${escapeRegExp(header)}$`, "i");

  for (let i = startIndex; i < lines.length; i += 1) {
    if (!pattern.test(lines[i])) continue;

    let headerIdx = i;

    for (let j = i + 1; j < Math.min(lines.length, i + 12); j += 1) {
      if (pattern.test(lines[j])) {
        headerIdx = j;
        continue;
      }

      if (sameText(lines[j], event)) {
        return headerIdx;
      }

      if (isHardStopLine(lines[j])) {
        break;
      }
    }
  }

  return -1;
}

function looksLikePropSubject(value) {
  const text = normalizeLine(value);

  if (looksLikePlayerToken(text)) return true;

  return /^(.*?)\s+Total\s+(Goals|Assists|Power Play Points|Saves|Hits)$/i.test(text);
}

function normalizePropSubjectToPlayer(value) {
  const text = normalizeLine(value);

  return text
    .replace(/\s+Total\s+Goals$/i, "")
    .replace(/\s+Total\s+Assists$/i, "")
    .replace(/\s+Total\s+Power Play Points$/i, "")
    .replace(/\s+Total\s+Saves$/i, "")
    .replace(/\s+Total\s+Hits$/i, "");
}

function findLineIndexAfter(lines, startIndex, pattern) {
  for (let i = startIndex; i < lines.length; i += 1) {
    if (pattern.test(lines[i])) return i;
  }
  return -1;
}

function findNextSectionIndex(lines, startIndex) {
  for (let i = startIndex; i < lines.length; i += 1) {
    if (isLikelySectionHeader(lines[i]) || isHardStopLine(lines[i])) return i;
  }
  return lines.length;
}

function isLiveMarker(value) {
  return /^LIVE$/i.test(normalizeLine(value));
}

function isLiveClockLine(value) {
  const text = normalizeLine(value);
  return /^(1st|2nd|3rd|4th)\s+\d{1,2}:\d{2}$/i.test(text) || /^(1st|2nd|3rd|4th)\s+\d{1,2}:\d{2}:\d{2}$/i.test(text);
}

function isHardStopLine(value) {
  return /^(Betting News|VIEW FULL ARTICLE|Author\(s\):|About|Privacy Policy|Responsible Gaming|Terms Of Use|If you or someone you know|Gambling can be addictive|BACK TO TOP)$/i.test(normalizeLine(value));
}

function parseAmericanOdds(value) {
  const text = normalizeLine(value);
  if (/^Even$/i.test(text)) return 100;
  if (!/^[+-]\d{2,5}$/.test(text)) return null;
  const n = Number(text);
  return Number.isFinite(n) ? n : null;
}

function parseSignedNumber(value) {
  const text = normalizeLine(value);
  if (!/^[+-]\d+(\.\d+)?$/.test(text)) return null;
  const n = Number(text);
  return Number.isFinite(n) ? n : null;
}

function parseUnsignedNumber(value) {
  const text = normalizeLine(value);
  if (!/^\d+(\.\d+)?$/.test(text)) return null;
  const n = Number(text);
  return Number.isFinite(n) ? n : null;
}

function parseTotalToken(value, expectedSide) {
  const text = normalizeLine(value);
  const m = text.match(/^([OU])\s*(\d+(?:\.\d+)?)$/i);
  if (!m) return null;
  if (expectedSide && m[1].toUpperCase() !== String(expectedSide).toUpperCase()) return null;
  return Number(m[2]);
}

function looksLikeOuToken(value, expectedSide) {
  return parseOuLine(value, expectedSide) !== null;
}

function parseOuLine(value, expectedSide) {
  const text = normalizeLine(value);
  const m = text.match(/^([OU])\s*(\d+(?:\.\d+)?)$/i);
  if (!m) return null;
  if (expectedSide && m[1].toUpperCase() !== String(expectedSide).toUpperCase()) return null;
  return Number(m[2]);
}

function looksLikeComboPlayerLabel(value) {
  const text = normalizeLine(value);

  return / - Alt (Pts \+ Reb \+ Ast|Pts \+ Reb|Pts \+ Ast|Reb \+ Ast)$/i.test(text);
}

function inferComboMarketTypeFromPlayerLabel(value) {
  const text = normalizeLine(value);

  if (/ - Alt Pts \+ Reb \+ Ast$/i.test(text)) return "player_pra";
  if (/ - Alt Pts \+ Reb$/i.test(text)) return "player_points_rebounds";
  if (/ - Alt Pts \+ Ast$/i.test(text)) return "player_points_assists";
  if (/ - Alt Reb \+ Ast$/i.test(text)) return "player_rebounds_assists";

  return "";
}

function normalizeComboPlayerLabel(value) {
  return normalizeLine(value)
    .replace(/ - Alt Pts \+ Reb \+ Ast$/i, "")
    .replace(/ - Alt Pts \+ Reb$/i, "")
    .replace(/ - Alt Pts \+ Ast$/i, "")
    .replace(/ - Alt Reb \+ Ast$/i, "");
}

function inferNearestLadderMarketType(lines, index) {
  for (let i = index - 1; i >= Math.max(0, index - 12); i -= 1) {
    const text = normalizeLine(lines[i]);

    if (/^Pts \+ Reb \+ Ast$/i.test(text)) return "player_pra";
    if (/^Pts \+ Reb$/i.test(text)) return "player_points_rebounds";
    if (/^Pts \+ Ast$/i.test(text)) return "player_points_assists";
    if (/^Reb \+ Ast$/i.test(text)) return "player_rebounds_assists";
    if (/^Points$/i.test(text)) return "player_points";
    if (/^Rebounds$/i.test(text)) return "player_rebounds";
    if (/^Assists$/i.test(text)) return "player_assists";
    if (/^3-Pointers Made$/i.test(text)) return "player_threes";
  }

  return "";
}

function findNextSectionEndForLadders(lines, startIndex) {
  for (let i = startIndex; i < lines.length; i += 1) {
    const text = normalizeLine(lines[i]);

    if (isHardStopLine(text)) return i;

    if (/^(Points|Rebounds|Assists|3-Pointers Made|Pts \+ Reb \+ Ast|Pts \+ Reb|Pts \+ Ast|Reb \+ Ast|Double Double|Triple Double|Shots On Goal|Goals|Saves|Hits|Power Play Points)$/i.test(text)) {
      return i;
    }
  }

  return lines.length;
}

function extractPlusTokensFromLine(value) {
  const text = normalizeLine(value);
  const matches = text.match(/\d+(?:\.\d+)?\+/g);
  if (!matches) return [];
  return matches.map((token) => Number(token.replace(/\+$/, ""))).filter(Number.isFinite);
}

function parsePlusToken(value) {
  const text = normalizeLine(value);
  const m = text.match(/^(\d+(?:\.\d+)?)\+$/);
  return m ? Number(m[1]) : null;
}

function buildRow({ sport, event, marketType, selection, lineValue, oddsAmerican }) {
  return {
    id: makeId(),
    sportsbook: "TheScore",
    sport,
    eventLabelRaw: event,
    marketType,
    betType: marketType,
    selectionRaw: selection,
    selectionNormalized: selection,
    lineValue,
    oddsAmerican,
    oddsDecimal: Number.isFinite(oddsAmerican) ? americanToDecimal(oddsAmerican) : null,
    isSharpSource: false,
    isTargetBook: true,
    batchRole: "target",
    confidence: "medium",
    parseWarnings: [],
  };
}

function dedupeRows(rows) {
  const seen = new Set();
  return rows.filter((row) => {
    const key = [row.sportsbook, row.sport, row.eventLabelRaw, row.marketType, row.selectionNormalized, row.lineValue ?? "", row.oddsAmerican ?? ""].join("::");
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function sameText(a, b) {
  return normalizeLine(a).toLowerCase() === normalizeLine(b).toLowerCase();
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}


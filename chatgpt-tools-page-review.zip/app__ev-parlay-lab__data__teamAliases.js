function cleanTeamNameDisplay(value = "") {
  return String(value || "")
    .replace(/[“”]/g, '"')
    .replace(/[’]/g, "'")
    .replace(/(^|\s)#\s*/g, "$1")
    .replace(/^[\s"'“”*#?&•·–—-]+/g, " ")
    .replace(/\bNeutral\s+(?:Venue|Site|Court|Field|Stadium|Arena|Ice|Location)\b/gi, " ")
    .replace(/\b(?:at|@)\s+Neutral\b/gi, " ")
    .replace(/\b(?:Venue|Neutral Site|Neutral Court|Neutral Field|Neutral Stadium|Neutral Arena)\b/gi, " ")
    .replace(/[\s,.;:!?#&]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeAliasKey(value = "") {
  return cleanTeamNameDisplay(value)
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function compactAliasKey(value = "") {
  return normalizeAliasKey(value).replace(/\s+/g, "");
}

function aliasIsSpecificEnoughForContainedMatch(aliasKey = "", sportKey = "") {
  const wordCount = String(aliasKey || "").split(" ").filter(Boolean).length;
  const compactLength = compactAliasKey(aliasKey).length;

  // Exact abbreviations still work through exact lookup. Contained matching needs
  // safer aliases so junk text does not turn "University of Houston" into the
  // Houston Rockets.
  return wordCount >= 2 || compactLength >= (sportKey ? 7 : 8);
}

function isLikelyTrailingOcrJunkForAlias(value = "") {
  const key = normalizeAliasKey(value);
  const compact = compactAliasKey(value);

  if (!key || !compact) return true;
  if (/\d{3,}/.test(compact)) return true;
  if (/\d/.test(compact) && /[a-z]/.test(compact)) return true;
  if (/^[o0l1i]{4,}\d*$/.test(compact)) return true;

  return false;
}

function aliasAllowsTrailingOcrJunk(aliasKey = "", canonical = "") {
  const key = normalizeAliasKey(aliasKey);
  const canonicalKey = normalizeAliasKey(canonical);
  const wordCount = key.split(" ").filter(Boolean).length;
  const compactLength = compactAliasKey(key).length;

  return wordCount >= 2 || (key === canonicalKey && compactLength >= 5);
}

function addAliases(map, sport, canonical, aliases) {
  if (!map[sport]) map[sport] = {};
  const all = [canonical, ...aliases];

  for (const alias of all) {
    const key = normalizeAliasKey(alias);
    if (key) map[sport][key] = canonical;
  }
}

export const TEAM_ALIASES_BY_SPORT = {};

function lookupExactTeamAlias(lookupKey = "", sportKey = "") {
  if (!lookupKey) return "";

  // If a league/sport was supplied, only search that league/sport.
  // This prevents NCAA/manual teams like "University of Houston" from
  // becoming Houston Rockets or "University of Arizona" from becoming
  // Arizona Diamondbacks.
  if (sportKey) {
    return TEAM_ALIASES_BY_SPORT[sportKey]?.[lookupKey] || "";
  }

  for (const key of Object.keys(TEAM_ALIASES_BY_SPORT)) {
    if (TEAM_ALIASES_BY_SPORT[key][lookupKey]) {
      return TEAM_ALIASES_BY_SPORT[key][lookupKey];
    }
  }

  return "";
}

function lookupContainedTeamAlias(lookupKey = "", sportKey = "") {
  if (!lookupKey) return "";

  // If a league/sport was supplied but there is no alias map for it, do not
  // fall back to every pro team map. Return the cleaned manual team text.
  const sportKeys = sportKey
    ? (TEAM_ALIASES_BY_SPORT[sportKey] ? [sportKey] : [])
    : Object.keys(TEAM_ALIASES_BY_SPORT);

  const paddedLookup = ` ${lookupKey} `;
  const compactLookup = compactAliasKey(lookupKey);
  let bestMatch = null;

  for (const key of sportKeys) {
    const aliasMap = TEAM_ALIASES_BY_SPORT[key] || {};

    for (const [aliasKey, canonical] of Object.entries(aliasMap)) {
      if (!aliasKey || !canonical) continue;
      if (aliasKey === lookupKey) continue;

      const canonicalKey = normalizeAliasKey(canonical);
      const aliasCandidates = Array.from(new Set([aliasKey, canonicalKey].filter(Boolean)));

      for (const candidateKey of aliasCandidates) {
        if (!aliasIsSpecificEnoughForContainedMatch(candidateKey, sportKey)) continue;

        const paddedAlias = ` ${candidateKey} `;
        const compactAlias = compactAliasKey(candidateKey);

        const wordContained = paddedLookup.includes(paddedAlias);
        const compactContained = compactAlias && compactLookup.includes(compactAlias);
        const trailingOcrJunkMatch =
          paddedLookup.startsWith(paddedAlias) &&
          aliasAllowsTrailingOcrJunk(candidateKey, canonical) &&
          isLikelyTrailingOcrJunkForAlias(lookupKey.slice(candidateKey.length).trim());

        if (!wordContained && !compactContained && !trailingOcrJunkMatch) continue;

        const wordCount = candidateKey.split(" ").filter(Boolean).length;
        const score =
          candidateKey.length +
          wordCount * 10 +
          (canonicalKey === candidateKey ? 25 : 0) +
          (trailingOcrJunkMatch ? 75 : 0);

        if (!bestMatch || score > bestMatch.score) {
          bestMatch = { canonical, score };
        }
      }
    }
  }

  return bestMatch?.canonical || "";
}

function isCollegeSportKeyForAliases(sportKey = "") {
  return ["NCAA", "NCAAM", "NCAAW", "NCAAB", "NCAAF", "CBB", "CFB", "COLLEGE"].includes(
    String(sportKey || "").trim().toUpperCase()
  );
}

export function normalizeTeamNameBySport(name = "", sport = "") {
  const clean = cleanTeamNameDisplay(name);
  if (!clean) return "";

  const sportKey = String(sport || "").trim().toUpperCase();
  const lookupKey = normalizeAliasKey(clean);

  if (isCollegeSportKeyForAliases(sportKey)) return clean;

  const exact = lookupExactTeamAlias(lookupKey, sportKey);
  if (exact) return exact;

  const contained = lookupContainedTeamAlias(lookupKey, sportKey);
  if (contained) return contained;

  return clean;
}

/* =========================
   NBA
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Atlanta Hawks", ["atl", "atlanta", "hawks", "atl hawks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Boston Celtics", ["bos", "boston", "celtics", "bos celtics"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Brooklyn Nets", ["bkn", "bk", "brooklyn", "nets", "bkn nets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Charlotte Hornets", ["cha", "charlotte", "hornets", "cha hornets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Chicago Bulls", [
  "chi",
  "chicago",
  "bulls",
  "chi bulls",
  "chicago bull",
  "chi bull",
  "* chi bulls",
  "” chi bulls",
  '" chi bulls',
]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Cleveland Cavaliers", ["cle", "cavs", "cavaliers", "cle cavaliers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Dallas Mavericks", ["dal", "dallas", "mavs", "mavericks", "dal mavericks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Denver Nuggets", ["den", "denver", "nuggets", "den nuggets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Detroit Pistons", ["det", "detroit", "pistons", "det pistons"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Golden State Warriors", ["gs", "gsw", "golden state", "warriors", "gs warriors", "gsw warriors"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Houston Rockets", ["hou", "houston", "rockets", "hou rockets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Indiana Pacers", ["ind", "indy", "indiana", "pacers", "ind pacers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Los Angeles Clippers", ["lac", "la clippers", "clippers", "los angeles clippers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Los Angeles Lakers", ["lal", "la lakers", "lakers", "los angeles lakers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Memphis Grizzlies", ["mem", "memphis", "grizzlies", "mem grizzlies"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Miami Heat", ["mia", "miami", "heat", "mia heat"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Milwaukee Bucks", ["mil", "milwaukee", "bucks", "mil bucks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Minnesota Timberwolves", ["min", "minnesota", "wolves", "timberwolves", "min timberwolves"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "New Orleans Pelicans", ["no", "nop", "new orleans", "pelicans", "nop pelicans"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "New York Knicks", ["ny", "nyk", "new york", "knicks", "ny knicks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Oklahoma City Thunder", ["okc", "oklahoma city", "thunder", "okc thunder"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Orlando Magic", ["orl", "orlando", "magic", "orl magic"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Philadelphia 76ers", ["phi", "philadelphia", "76ers", "sixers", "phi 76ers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Phoenix Suns", ["phx", "phoenix", "suns", "phx suns"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Portland Trail Blazers", ["por", "portland", "blazers", "trail blazers", "por blazers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Sacramento Kings", ["sac", "sacramento", "kings", "sac kings"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "San Antonio Spurs", ["sa", "sas", "san antonio", "spurs", "sas spurs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Toronto Raptors", ["tor", "toronto", "raptors", "tor raptors"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Utah Jazz", ["utah", "uta", "jazz", "uta jazz"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Washington Wizards", ["wsh", "was", "washington", "wizards", "was wizards"]);
// TheScore-style abbreviations (CRITICAL)
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Golden State Warriors", ["gs warriors"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Cleveland Cavaliers", ["cle cavaliers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "San Antonio Spurs", ["sa spurs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "New York Knicks", ["ny knicks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "New Orleans Pelicans", ["no pelicans"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Oklahoma City Thunder", ["okc thunder"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Los Angeles Clippers", ["la clippers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Los Angeles Lakers", ["la lakers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Phoenix Suns", ["phx suns"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Portland Trail Blazers", ["por trail blazers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Charlotte Hornets", ["cha hornets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Philadelphia 76ers", ["phi 76ers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Orlando Magic", ["orl magic"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NBA", "Miami Heat", ["mia heat"]);

/* =========================
   WNBA
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Atlanta Dream", ["atl", "atl dream", "atlanta", "atlanta dream", "dream"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Chicago Sky", ["chi", "chi sky", "chicago", "chicago sky", "sky"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Connecticut Sun", ["con", "ct", "con sun", "ct sun", "connecticut", "connecticut sun", "sun"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Dallas Wings", ["dal", "dal wings", "dallas", "dallas wings", "wings"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Golden State Valkyries", ["gs", "gsv", "gs valkyries", "gsv valkyries", "golden state", "golden state valkyries", "valkyries"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Indiana Fever", ["ind", "ind fever", "indiana", "indiana fever", "fever"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Las Vegas Aces", ["lv", "lva", "lv aces", "lva aces", "las vegas", "las vegas aces", "aces"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Los Angeles Sparks", ["la", "las", "la sparks", "las sparks", "los angeles", "los angeles sparks", "sparks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Minnesota Lynx", ["min", "min lynx", "minnesota", "minnesota lynx", "lynx"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "New York Liberty", ["ny", "nyl", "ny liberty", "nyl liberty", "new york", "new york liberty", "liberty"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Phoenix Mercury", ["phx", "pho", "phx mercury", "pho mercury", "phoenix", "phoenix mercury", "mercury"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Portland Fire", ["por", "por fire", "portland", "portland fire", "fire"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Seattle Storm", ["sea", "sea storm", "seattle", "seattle storm", "storm"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Toronto Tempo", ["tor", "tor tempo", "toronto", "toronto tempo", "tempo"]);
addAliases(TEAM_ALIASES_BY_SPORT, "WNBA", "Washington Mystics", ["was", "wsh", "was mystics", "wsh mystics", "washington", "washington mystics", "mystics"]);

/* =========================
   NHL
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Anaheim Ducks", ["ana", "anaheim", "ducks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Boston Bruins", ["bos", "boston", "bruins"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Buffalo Sabres", ["buf", "buffalo", "sabres"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Calgary Flames", ["cgy", "calgary", "flames"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Carolina Hurricanes", ["car", "carolina", "hurricanes", "canes"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Chicago Blackhawks", ["chi", "chicago", "blackhawks", "hawks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Colorado Avalanche", ["col", "colorado", "avalanche", "avs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Columbus Blue Jackets", ["cbj", "columbus", "blue jackets", "jackets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Dallas Stars", ["dal", "dallas", "stars"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Detroit Red Wings", ["det", "detroit", "red wings", "wings"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Edmonton Oilers", ["edm", "edmonton", "oilers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Florida Panthers", ["fla", "florida", "panthers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Los Angeles Kings", ["la", "lak", "kings", "la kings"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Minnesota Wild", ["min", "minnesota", "wild"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Montreal Canadiens", ["mtl", "montreal", "canadiens", "habs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Nashville Predators", ["nsh", "nashville", "predators", "preds"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "New Jersey Devils", ["nj", "njd", "new jersey", "devils"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "New York Islanders", ["nyi", "islanders"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "New York Rangers", ["nyr", "rangers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Ottawa Senators", ["ott", "ottawa", "senators", "sens"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Philadelphia Flyers", ["phi", "philadelphia", "flyers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Pittsburgh Penguins", ["pit", "pittsburgh", "penguins", "pens"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "San Jose Sharks", ["sj", "sjs", "san jose", "sharks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Seattle Kraken", ["sea", "seattle", "kraken"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "St. Louis Blues", ["stl", "st louis", "saint louis", "blues"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Tampa Bay Lightning", ["tb", "tbl", "tampa", "tampa bay", "tampa lightning", "tb lightning", "tbl lightning", "lightning", "bolts"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Toronto Maple Leafs", ["tor", "toronto", "maple leafs", "leafs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Utah Hockey Club", ["utah", "utah hockey club", "utah hc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Utah Hockey Club", ["utah mammoth", "mammoth"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Vancouver Canucks", ["van", "vancouver", "canucks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Vegas Golden Knights", ["vgk", "vegas", "golden knights", "knights"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Washington Capitals", ["wsh", "was", "washington", "capitals", "caps"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Winnipeg Jets", ["wpg", "winnipeg", "jets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Boston Bruins", ["bos bruins"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Buffalo Sabres", ["buf sabres"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Carolina Hurricanes", ["car hurricanes"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Ottawa Senators", ["ott senators"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Colorado Avalanche", ["col avalanche"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Dallas Stars", ["dal stars"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Minnesota Wild", ["min wild"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Montreal Canadiens", ["mtl canadiens", "mon canadiens"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Los Angeles Kings", ["la kings", "lak kings"]);
// TheScore / sportsbook-style NHL combined aliases
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Anaheim Ducks", ["ana ducks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Boston Bruins", ["bos bruins"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Buffalo Sabres", ["buf sabres"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Calgary Flames", ["cgy flames"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Carolina Hurricanes", ["car hurricanes"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Chicago Blackhawks", ["chi blackhawks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Colorado Avalanche", ["col avalanche"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Columbus Blue Jackets", ["cbj blue jackets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Dallas Stars", ["dal stars"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Detroit Red Wings", ["det red wings"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Edmonton Oilers", ["edm oilers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Florida Panthers", ["fla panthers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Los Angeles Kings", ["la kings", "lak kings"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Minnesota Wild", ["min wild"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Montreal Canadiens", ["mtl canadiens", "mon canadiens"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Nashville Predators", ["nsh predators"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "New Jersey Devils", ["nj devils", "njd devils"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "New York Islanders", ["nyi islanders"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "New York Rangers", ["ny rangers", "nyr rangers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Ottawa Senators", ["ott senators"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Philadelphia Flyers", ["phi flyers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Pittsburgh Penguins", ["pit penguins"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "San Jose Sharks", ["sj sharks", "sjs sharks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Seattle Kraken", ["sea kraken"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "St. Louis Blues", ["stl blues"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Tampa Bay Lightning", ["tb lightning", "tbl lightning", "tampa", "tampa lightning"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Toronto Maple Leafs", ["tor maple leafs", "tor leafs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Utah Hockey Club", ["uta hockey club", "utah mammoth", "uta mammoth"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Vancouver Canucks", ["van canucks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Vegas Golden Knights", ["vgk golden knights", "vegas golden knights"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Washington Capitals", ["wsh capitals", "was capitals"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NHL", "Winnipeg Jets", ["wpg jets"]);

/* =========================
   MLB
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Arizona Diamondbacks", ["ari", "ari diamondbacks", "arizona", "arizona diamondbacks", "diamondbacks", "dbacks", "d-backs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Atlanta Braves", ["atl", "atl braves", "atlanta", "atlanta braves", "braves"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Baltimore Orioles", ["bal", "bal orioles", "baltimore", "baltimore orioles", "orioles", "o's", "os"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Boston Red Sox", ["bos", "bos red sox", "boston", "boston red sox", "red sox"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Chicago Cubs", ["chc", "chi cubs", "chicago cubs", "cubs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Chicago White Sox", ["chw", "cws", "chi white sox", "chicago white sox", "white sox"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Cincinnati Reds", ["cin", "cin reds", "cincinnati", "cincinnati reds", "reds"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Cleveland Guardians", ["cle", "cle guardians", "cleveland", "cleveland guardians", "guardians"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Colorado Rockies", ["col", "col rockies", "colorado", "colorado rockies", "rockies"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Detroit Tigers", ["det", "det tigers", "detroit", "detroit tigers", "tigers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Houston Astros", ["hou", "hou astros", "houston", "houston astros", "astros"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Kansas City Royals", ["kc", "kcr", "kc royals", "kansas city", "kansas city royals", "royals"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Los Angeles Angels", ["laa", "la angels", "los angeles angels", "angels"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Los Angeles Dodgers", ["lad", "la dodgers", "los angeles dodgers", "dodgers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Miami Marlins", ["mia", "mia marlins", "miami", "miami marlins", "marlins"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Milwaukee Brewers", ["mil", "mil brewers", "milwaukee", "milwaukee brewers", "brewers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Minnesota Twins", ["min", "min twins", "minnesota", "minnesota twins", "twins"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "New York Mets", ["nym", "ny mets", "new york mets", "mets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "New York Yankees", ["nyy", "ny yankees", "new york yankees", "yankees"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Athletics", ["ath", "oak", "oak athletics", "oakland", "oakland athletics", "a's", "as", "athletics"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Philadelphia Phillies", ["phi", "phi phillies", "philadelphia", "philadelphia phillies", "phillies"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Pittsburgh Pirates", ["pit", "pit pirates", "pittsburgh", "pittsburgh pirates", "pirates"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "San Diego Padres", ["sd", "sdp", "sd padres", "san diego", "san diego padres", "padres"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "San Francisco Giants", ["sf", "sfg", "sf giants", "san francisco", "san francisco giants", "giants"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Seattle Mariners", ["sea", "sea mariners", "seattle", "seattle mariners", "mariners"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "St. Louis Cardinals", ["stl", "stl cardinals", "st louis", "st. louis", "saint louis", "st. louis cardinals", "st louis cardinals", "cardinals", "cards"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Tampa Bay Rays", ["tb", "tbr", "tb rays", "tampa bay", "tampa bay rays", "rays"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Texas Rangers", ["tex", "tex rangers", "texas", "texas rangers", "rangers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Toronto Blue Jays", ["tor", "tor blue jays", "toronto", "toronto blue jays", "blue jays", "jays"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Washington Nationals", ["wsh", "was", "wsh nationals", "washington", "washington nationals", "nationals", "nats"]);

// International baseball / WBC national teams.
// Keep these in the MLB/Baseball alias bucket so Baseball rows like
// "USA @ Mexico" validate and normalize without requiring a separate league.
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "United States", ["usa", "u s a", "us", "united states", "team usa", "united states baseball"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Mexico", ["mex", "mexico", "team mexico", "mexico baseball"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Canada", ["can", "canada", "team canada", "canada baseball"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Japan", ["jpn", "japan", "team japan", "japan baseball"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Dominican Republic", ["dom", "dr", "dominican", "dominican republic", "team dominican republic"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Puerto Rico", ["pur", "pr", "puerto rico", "team puerto rico"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Cuba", ["cub", "cuba", "team cuba"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Venezuela", ["ven", "venezuela", "team venezuela"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Colombia", ["col", "colombia", "team colombia"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Panama", ["pan", "panama", "team panama"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Nicaragua", ["nca", "nic", "nicaragua", "team nicaragua"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Italy", ["ita", "italy", "team italy"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Netherlands", ["ned", "netherlands", "holland", "team netherlands"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Australia", ["aus", "australia", "team australia"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "South Korea", ["kor", "korea", "south korea", "korea republic", "team korea", "team south korea"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Chinese Taipei", ["tpe", "taiwan", "chinese taipei", "team chinese taipei"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Israel", ["isr", "israel", "team israel"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Great Britain", ["gbr", "great britain", "britain", "team great britain"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Czech Republic", ["cze", "czech republic", "czechia", "team czech republic"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "China", ["chn", "china", "china pr", "team china"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Brazil", ["bra", "brazil", "team brazil"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Spain", ["esp", "spain", "team spain"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "Germany", ["ger", "germany", "deutschland", "team germany"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "France", ["fra", "france", "team france"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLB", "South Africa", ["rsa", "zaf", "south africa", "team south africa"]);


/* =========================
   NFL
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Arizona Cardinals", ["ari", "arizona", "cardinals", "cards"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Atlanta Falcons", ["atl", "atlanta", "falcons"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Baltimore Ravens", ["bal", "baltimore", "ravens"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Buffalo Bills", ["buf", "buffalo", "bills"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Carolina Panthers", ["car", "carolina", "panthers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Chicago Bears", ["chi", "chicago", "bears"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Cincinnati Bengals", ["cin", "cincinnati", "bengals"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Cleveland Browns", ["cle", "cleveland", "browns"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Dallas Cowboys", ["dal", "dallas", "cowboys"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Denver Broncos", ["den", "denver", "broncos"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Detroit Lions", ["det", "detroit", "lions"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Green Bay Packers", ["gb", "packers", "green bay"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Houston Texans", ["hou", "houston", "texans"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Indianapolis Colts", ["ind", "indy", "colts"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Jacksonville Jaguars", ["jax", "jacksonville", "jaguars", "jags"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Kansas City Chiefs", ["kc", "chiefs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Las Vegas Raiders", ["lv", "raiders"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Los Angeles Chargers", ["lac", "chargers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Los Angeles Rams", ["lar", "rams"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Miami Dolphins", ["mia", "miami", "dolphins"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Minnesota Vikings", ["min", "minnesota", "vikings"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "New England Patriots", ["ne", "patriots"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "New Orleans Saints", ["no", "saints"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "New York Giants", ["nyg", "giants"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "New York Jets", ["nyj", "jets"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Philadelphia Eagles", ["phi", "eagles"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Pittsburgh Steelers", ["pit", "steelers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "San Francisco 49ers", ["sf", "49ers", "niners"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Seattle Seahawks", ["sea", "seahawks"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Tampa Bay Buccaneers", ["tb", "bucs", "buccaneers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Tennessee Titans", ["ten", "titans"]);
addAliases(TEAM_ALIASES_BY_SPORT, "NFL", "Washington Commanders", ["wsh", "was", "washington", "commanders"]);

/* =========================
   MLS
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Atlanta United", ["atlanta united"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Austin FC", ["austin", "austin fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Charlotte FC", ["charlotte fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Chicago Fire", ["chicago fire", "fire"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "FC Cincinnati", ["cincinnati", "fc cincinnati"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Colorado Rapids", ["colorado rapids", "rapids"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Columbus Crew", ["columbus crew", "crew"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "D.C. United", ["dc united", "d.c. united"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "FC Dallas", ["fc dallas", "dallas"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Houston Dynamo", ["houston dynamo", "dynamo"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Inter Miami CF", ["inter miami", "miami cf"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "LA Galaxy", ["la galaxy", "galaxy"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Los Angeles FC", ["lafc", "los angeles fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Minnesota United", ["minnesota united"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "CF Montréal", ["montreal", "cf montreal", "cf montréal"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Nashville SC", ["nashville sc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "New England Revolution", ["new england revolution", "revolution", "revs"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "New York City FC", ["nycfc", "new york city fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "New York Red Bulls", ["ny red bulls", "red bulls"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Orlando City SC", ["orlando city", "orlando city sc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Philadelphia Union", ["philadelphia union", "union"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Portland Timbers", ["portland timbers", "timbers"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Real Salt Lake", ["real salt lake", "rsl"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "San Diego FC", ["san diego fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "San Jose Earthquakes", ["san jose earthquakes", "earthquakes", "quakes"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Seattle Sounders FC", ["seattle sounders", "sounders"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Sporting Kansas City", ["sporting kc", "sporting kansas city", "skc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "St. Louis City SC", ["st louis city", "saint louis city", "st. louis city", "city sc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Toronto FC", ["toronto fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "MLS", "Vancouver Whitecaps FC", ["vancouver whitecaps", "whitecaps"]);

/* =========================
   Premier League
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Arsenal", ["arsenal fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Aston Villa", ["villa", "aston villa fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Bournemouth", ["afc bournemouth", "bournemouth"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Brentford", ["brentford fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Brighton & Hove Albion", ["brighton", "brighton and hove albion"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Chelsea", ["chelsea fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Crystal Palace", ["palace", "crystal palace fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Everton", ["everton fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Fulham", ["fulham fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Ipswich Town", ["ipswich", "ipswich town fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Leicester City", ["leicester", "leicester city fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Liverpool", ["liverpool fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Manchester City", ["man city", "manchester city", "mci"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Manchester United", ["man united", "man utd", "manchester united", "mun"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Newcastle United", ["newcastle", "newcastle united fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Nottingham Forest", ["nottingham forest", "forest"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Southampton", ["southampton fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Tottenham Hotspur", ["tottenham", "spurs", "tottenham hotspur fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "West Ham United", ["west ham", "west ham united fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "EPL", "Wolverhampton Wanderers", ["wolves", "wolverhampton", "wolverhampton wanderers"]);

/* =========================
   Bundesliga
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "Bayern Munich", ["bayern", "fc bayern", "fc bayern munchen", "fc bayern münchen"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "Borussia Dortmund", ["dortmund", "bvb", "borussia dortmund"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "RB Leipzig", ["leipzig", "rbl", "rb leipzig"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "Bayer Leverkusen", ["leverkusen", "bayer leverkusen"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "Eintracht Frankfurt", ["frankfurt", "eintracht"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "VfB Stuttgart", ["stuttgart", "vfb stuttgart"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "VfL Wolfsburg", ["wolfsburg", "vfl wolfsburg"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "Borussia Mönchengladbach", ["gladbach", "monchengladbach", "mönchengladbach"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "Werder Bremen", ["bremen", "werder"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "SC Freiburg", ["freiburg"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "TSG Hoffenheim", ["hoffenheim"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "FSV Mainz 05", ["mainz", "mainz 05"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "FC Augsburg", ["augsburg"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "Union Berlin", ["union berlin"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "FC Heidenheim", ["heidenheim"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "FC St. Pauli", ["st pauli", "st. pauli"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "Holstein Kiel", ["holstein kiel", "kiel"]);
addAliases(TEAM_ALIASES_BY_SPORT, "BUNDESLIGA", "VfL Bochum", ["bochum"]);

/* =========================
   Ligue 1
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Paris Saint-Germain", ["psg", "paris sg", "paris saint germain"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Marseille", ["om", "olympique de marseille"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Monaco", ["as monaco"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Lille", ["lille osc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Lyon", ["ol", "olympique lyonnais"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Nice", ["ogc nice"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Lens", ["rc lens"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Rennes", ["stade rennes", "rennes"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Reims", ["stade reims"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Strasbourg", ["rc strasbourg"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Nantes", ["fc nantes"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Montpellier", ["montpellier hsc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Toulouse", ["toulouse fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Brest", ["stad brestois", "brest"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Auxerre", ["aj auxerre"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Le Havre", ["le havre ac"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Angers", ["angers sco"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LIGUE1", "Saint-Étienne", ["saint etienne", "st etienne", "saint-étienne"]);

/* =========================
   La Liga
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Real Madrid", ["rm", "real madrid cf"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Barcelona", ["barca", "fc barcelona"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Atlético Madrid", ["atletico madrid", "atleti"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Athletic Club", ["athletic bilbao", "bilbao"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Real Sociedad", ["sociedad", "real sociedad"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Real Betis", ["betis"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Sevilla", ["sevilla fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Villarreal", ["villarreal cf"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Valencia", ["valencia cf"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Getafe", ["getafe cf"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Celta Vigo", ["celta", "celta de vigo"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Osasuna", ["ca osasuna"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Mallorca", ["rcd mallorca"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Rayo Vallecano", ["rayo"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Girona", ["girona fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Alavés", ["alaves", "deportivo alaves", "deportivo alavés"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Las Palmas", ["ud las palmas"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Leganés", ["leganes", "cd leganés"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Espanyol", ["rcd espanyol"]);
addAliases(TEAM_ALIASES_BY_SPORT, "LALIGA", "Real Valladolid", ["valladolid"]);

/* =========================
   Serie A
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Inter Milan", ["inter", "internazionale"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "AC Milan", ["milan", "ac milan"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Juventus", ["juve"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Napoli", ["ssc napoli"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Roma", ["as roma"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Lazio", ["ss lazio"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Atalanta", ["atalanta bc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Bologna", ["bologna fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Fiorentina", ["acf fiorentina"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Torino", ["torino fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Genoa", ["genoa cfc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Monza", ["ac monza"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Udinese", ["udinese calcio"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Lecce", ["us lecce"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Parma", ["parma calcio"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Cagliari", ["cagliari calcio"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Hellas Verona", ["verona", "hellas"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Como", ["como 1907"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Empoli", ["empoli fc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "SERIEA", "Venezia", ["venezia fc"]);

/* =========================
   International Soccer
========================= */
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "United States", ["usa", "usmnt", "united states men", "united states national team"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Mexico", ["mex", "mexico national team"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Canada", ["can", "canada national team"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "England", ["eng"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "France", ["fra"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Germany", ["ger", "deutschland"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Spain", ["esp"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Italy", ["ita"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Portugal", ["por"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Netherlands", ["ned", "holland"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Belgium", ["bel"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Brazil", ["bra"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Argentina", ["arg"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Uruguay", ["uru"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Colombia", ["col"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Croatia", ["cro"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Switzerland", ["sui"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Denmark", ["den"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Poland", ["pol"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Japan", ["jpn"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "South Korea", ["kor", "korea republic"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Australia", ["aus"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Morocco", ["mar"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Nigeria", ["nga"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Egypt", ["egy"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Senegal", ["sen"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Cameroon", ["cmr"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Turkey", ["tur"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Austria", ["aut"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Czech Republic", ["cze"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Sweden", ["swe"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Norway", ["nor"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Serbia", ["srb"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Ukraine", ["ukr"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Chile", ["chi"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Peru", ["per"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Ecuador", ["ecu"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Paraguay", ["par"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Costa Rica", ["crc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Panama", ["pan"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Jamaica", ["jam"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Saudi Arabia", ["ksa"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Qatar", ["qat"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Iran", ["irn"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Iraq", ["irq"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Algeria", ["alg"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Bolivia", ["bol"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "China", ["chn", "china pr"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Côte d'Ivoire", ["cote d'ivoire", "côte d’ivoire", "ivory coast", "civ"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "DR Congo", ["democratic republic of congo", "congo dr", "drc"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Ghana", ["gha"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Greece", ["gre"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Honduras", ["hon"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Hungary", ["hun"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "New Zealand", ["nzl", "new zealand all whites"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Northern Ireland", ["nir"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Republic of Ireland", ["ireland", "irl"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Romania", ["rou", "romania"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Scotland", ["sco"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Slovakia", ["svk"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Slovenia", ["svn"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "South Africa", ["rsa", "zaf"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Tunisia", ["tun"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Türkiye", ["turkiye", "turkey", "tur"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Venezuela", ["ven"]);
addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Wales", ["wal"]);addAliases(TEAM_ALIASES_BY_SPORT, "INTL", "Draw", ["tie", "x"]);
